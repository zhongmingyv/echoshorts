'use strict';

importScripts('stream-analyzer.js');

// Per-tab: tabId -> [{url, format, source, timestamp, frameId, isAd}]
const tabStreams = new Map();

// --- webRequest interception ---
chrome.webRequest.onBeforeRequest.addListener(
  (details) => {
    if (details.tabId < 0) return;
    const url = details.url;
    if (TS_URL_PATTERN.test(url)) return;
    if (isStreamUrl(url)) {
      addStream(details.tabId, {
        url,
        format: detectFormat(url),
        source: 'webRequest',
        timestamp: Date.now(),
        isAd: isAdUrl(url),
        frameId: details.frameId,
      });
    }
  },
  { urls: ['<all_urls>'] }
);

chrome.webRequest.onHeadersReceived.addListener(
  (details) => {
    if (details.tabId < 0) return;
    const contentType = details.responseHeaders?.find(
      h => h.name.toLowerCase() === 'content-type'
    );
    if (contentType && isStreamMimeType(contentType.value)) {
      const url = details.url;
      if (TS_URL_PATTERN.test(url)) return;
      const detected = detectFormat(url);
      const mimeVal = contentType.value.toLowerCase();
      let format = detected !== 'unknown' ? detected : 'hls';
      // If MIME says video/mp4 and URL format is unknown, mark as mp4
      if (mimeVal.includes('video/mp4') && detected === 'unknown') format = 'mp4';
      addStream(details.tabId, {
        url,
        format,
        source: 'webRequest-mime',
        timestamp: Date.now(),
        isAd: isAdUrl(url),
        frameId: details.frameId,
      });
    }
  },
  { urls: ['<all_urls>'] },
  ['responseHeaders']
);

// --- Messages ---
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'stream-found' && sender.tab) {
    const urls = message.urls || [message.url];
    for (const url of urls) {
      if (!url) continue;
      if (TS_URL_PATTERN.test(url)) continue;
      addStream(sender.tab.id, {
        url,
        format: detectFormat(url),
        source: message.source || 'content-script',
        timestamp: Date.now(),
        isAd: isAdUrl(url),
        frameId: sender.frameId || 0,
      });
    }
    sendResponse({ ok: true });
  }

  if (message.type === 'stream-video-mapped' && sender.tab) {
    sendResponse({ ok: true });
  }

  // Get grouped streams for popup
  if (message.type === 'get-streams') {
    const streams = tabStreams.get(message.tabId) || [];
    const grouped = groupAndRank(streams);
    sendResponse({ streams: grouped });
  }

  // Highlight: forward to content scripts
  if (message.type === 'highlight-video') {
    chrome.tabs.sendMessage(message.tabId, {
      type: 'highlight-video',
      videoId: message.videoId,
    }).catch(() => {});
    sendResponse({ ok: true });
  }

  if (message.type === 'unhighlight-video') {
    chrome.tabs.sendMessage(message.tabId, { type: 'unhighlight-video' }).catch(() => {});
    sendResponse({ ok: true });
  }

  if (message.type === 'play-stream') {
    playStream(message.url, message.referer);
    sendResponse({ ok: true });
  }

  if (message.type === 'clear-streams') {
    tabStreams.delete(message.tabId);
    updateBadge(message.tabId, 0);
    sendResponse({ ok: true });
  }

  return true;
});

// --- Group by video ID and pick best quality per group ---
// Extract video ID from URL path, e.g.:
//   /hls/197467228/master/197467228_720p.m3u8 → "197467228"
//   /video/index.m3u8 → null (use full URL as ID)
function extractVideoId(url) {
  try {
    const path = new URL(url).pathname;
    // Pattern: /hls/<id>/  or /<id>/master/ or /<id>_720p.m3u8
    const match = path.match(/\/(\d{6,})\//);
    if (match) return match[1];
    // Try filename: 197467228_720p.m3u8
    const fileMatch = path.match(/\/(\d{6,})[_\.]/);
    if (fileMatch) return fileMatch[1];
  } catch (e) { /* */ }
  return null;
}

// Quality ranking for resolution suffixes
const QUALITY_ORDER = ['720p', '1080p', '480p', '360p', '240p', '160p'];

function getQualityScore(url) {
  // Master playlist (no resolution suffix) = highest
  const path = url.toLowerCase();
  if (/master\.m3u8/i.test(path) && !/_\d+p/.test(path)) return 100;
  if (/auto/i.test(path)) return 90;
  if (/1080p/i.test(path)) return 80;
  if (/720p/i.test(path)) return 70;
  if (/480p/i.test(path)) return 60;
  if (/360p/i.test(path)) return 50;
  if (/240p/i.test(path)) return 40;
  if (/160p/i.test(path)) return 30;
  if (/blurred/i.test(path)) return 10;
  return 55; // unknown quality
}

function groupAndRank(streams) {
  const filtered = streams.filter(s => !s.isAd);
  if (filtered.length === 0) return [];

  // Group by video ID
  const groups = new Map(); // videoId → [streams]
  const ungrouped = [];

  for (const s of filtered) {
    const vid = extractVideoId(s.url);
    if (vid) {
      if (!groups.has(vid)) groups.set(vid, []);
      groups.get(vid).push(s);
    } else {
      ungrouped.push(s);
    }
  }

  const result = [];

  // For each group, pick the best quality stream
  for (const [videoId, groupStreams] of groups) {
    // Sort by quality score descending
    groupStreams.sort((a, b) => getQualityScore(b.url) - getQualityScore(a.url));
    const best = groupStreams[0];
    result.push({
      ...best,
      videoId,
      quality: getQualityLabel(best.url),
      variantCount: groupStreams.length,
    });
  }

  // Add ungrouped streams
  for (const s of ungrouped) {
    result.push({
      ...s,
      videoId: null,
      quality: getQualityLabel(s.url),
      variantCount: 1,
    });
  }

  // Sort: highest quality first
  result.sort((a, b) => getQualityScore(b.url) - getQualityScore(a.url));

  return result;
}

function getQualityLabel(url) {
  const path = url.toLowerCase();
  if (/1080p/i.test(path)) return '1080p';
  if (/720p/i.test(path)) return '720p';
  if (/480p/i.test(path)) return '480p';
  if (/360p/i.test(path)) return '360p';
  if (/240p/i.test(path)) return '240p';
  if (/160p/i.test(path)) return '160p';
  if (/auto/i.test(path)) return 'Auto';
  if (/master/i.test(path)) return 'Master';
  return '';
}

// --- Stream management ---
function addStream(tabId, entry) {
  let list = tabStreams.get(tabId);
  if (!list) {
    list = [];
    tabStreams.set(tabId, list);
  }
  if (list.some(s => s.url === entry.url)) return;
  list.push(entry);
  console.log('[m3u8-grabber] Stream found:', entry.format, entry.url);
  const count = groupAndRank(list).length;
  updateBadge(tabId, count);
}

function updateBadge(tabId, count) {
  const text = count > 0 ? String(count) : '';
  chrome.action.setBadgeText({ text, tabId });
  chrome.action.setBadgeBackgroundColor({ color: '#e53935', tabId });
}

// --- Play stream in new tab with Referer injection ---
const REFERER_RULE_ID_START = 1000;
let nextRuleId = REFERER_RULE_ID_START;

async function playStream(streamUrl, referer) {
  if (referer) {
    // Extract domain from stream URL to scope the rule
    let urlFilter;
    try {
      const u = new URL(streamUrl);
      urlFilter = '*://' + u.hostname + '/*';
    } catch (e) {
      urlFilter = streamUrl;
    }

    const ruleId = nextRuleId++;
    // Add dynamic rule to set Referer header for this domain
    await chrome.declarativeNetRequest.updateDynamicRules({
      removeRuleIds: [ruleId],
      addRules: [{
        id: ruleId,
        priority: 1,
        action: {
          type: 'modifyHeaders',
          requestHeaders: [
            { header: 'Referer', operation: 'set', value: referer },
            { header: 'Origin', operation: 'set', value: referer.replace(/\/$/, '') },
          ],
        },
        condition: {
          urlFilter,
          resourceTypes: ['xmlhttprequest', 'media', 'other'],
        },
      }],
    });

    // Clean up rule after 10 minutes
    setTimeout(() => {
      chrome.declarativeNetRequest.updateDynamicRules({
        removeRuleIds: [ruleId],
      }).catch(() => {});
    }, 600000);
  }

  // Open player page
  const playerUrl = chrome.runtime.getURL('player.html') +
    '?url=' + encodeURIComponent(streamUrl) +
    '&referer=' + encodeURIComponent(referer);
  chrome.tabs.create({ url: playerUrl });
}

chrome.tabs.onRemoved.addListener((tabId) => tabStreams.delete(tabId));

chrome.tabs.onUpdated.addListener((tabId, changeInfo) => {
  if (changeInfo.status === 'loading' && changeInfo.url) {
    tabStreams.delete(tabId);
    updateBadge(tabId, 0);
  }
});
