'use strict';

/**
 * Stream URL detection and analysis — adapted from m3u8-grabber/main/stream-analyzer.js
 * Runs in service worker context (no DOM)
 */

const STREAM_MIME_TYPES = [
  'application/vnd.apple.mpegurl',
  'application/x-mpegurl',
  'audio/mpegurl',
  'audio/x-mpegurl',
  'application/dash+xml',
  'video/x-flv',
  'video/mp2t',
  'video/mp4',
];

const STREAM_URL_PATTERNS = /\.(m3u8|mpd|flv|mp4)(\?|$)/i;
const TS_URL_PATTERN = /\.(ts)(\?|$)/i;

function isStreamUrl(url) {
  return STREAM_URL_PATTERNS.test(url);
}

function isStreamMimeType(mimeType) {
  if (!mimeType) return false;
  const lower = mimeType.toLowerCase().split(';')[0].trim();
  return STREAM_MIME_TYPES.includes(lower);
}

function detectFormat(url) {
  if (/\.m3u8(\?|$)/i.test(url)) return 'hls';
  if (/\.mpd(\?|$)/i.test(url)) return 'dash';
  if (/\.flv(\?|$)/i.test(url)) return 'flv';
  if (/\.ts(\?|$)/i.test(url)) return 'ts';
  if (/\.mp4(\?|$)/i.test(url)) return 'mp4';
  return 'unknown';
}

function isAdUrl(url) {
  return /\b(ad|preroll|midroll|commercial|trailer|preview)\b/i.test(url);
}

// Scan text for stream URLs (used for JSON responses)
function scanForStreamUrls(text) {
  if (!text || text.length > 102400) return [];
  const urls = [];
  const regex = /https?:\/\/[^\s"'\\]+\.(m3u8|mpd|flv|mp4)(?:[^\s"'\\]*)/gi;
  let match;
  while ((match = regex.exec(text)) !== null) {
    urls.push(match[0]);
  }
  return [...new Set(urls)];
}
