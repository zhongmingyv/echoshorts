'use strict';

// Runs in ISOLATED world.
// 1. Receives messages from page-hook.js (MAIN world) via postMessage
// 2. Forwards stream detections to background
// 3. Handles highlight: find video element by videoId in DOM

(function () {
  const MSG_TAG = '__m3u8_grabber__';

  // --- Receive from page-hook.js ---
  window.addEventListener('message', (event) => {
    if (event.source !== window) return;
    const data = event.data;
    if (!data || data.tag !== MSG_TAG) return;

    try {
      if (data.type === 'stream-found') {
        chrome.runtime.sendMessage({ type: 'stream-found', url: data.url, source: data.source });
      }
      if (data.type === 'stream-found-batch') {
        chrome.runtime.sendMessage({ type: 'stream-found', urls: data.urls, source: data.source });
      }
    } catch (e) { /* extension context invalidated */ }
  });

  // --- Highlight logic ---
  const HIGHLIGHT_CLASS = '__m3u8_grabber_highlight__';
  const HIGHLIGHT_STYLE_ID = '__m3u8_grabber_style__';

  function ensureHighlightStyle() {
    if (document.getElementById(HIGHLIGHT_STYLE_ID)) return;
    const style = document.createElement('style');
    style.id = HIGHLIGHT_STYLE_ID;
    style.textContent =
      '.' + HIGHLIGHT_CLASS + ' {' +
      '  outline: 4px solid #e53935 !important;' +
      '  outline-offset: -2px !important;' +
      '  box-shadow: 0 0 24px rgba(229,57,53,0.6) !important;' +
      '}';
    (document.head || document.documentElement).appendChild(style);
  }

  function unhighlightAll() {
    const els = document.querySelectorAll('.' + HIGHLIGHT_CLASS);
    for (const el of els) el.classList.remove(HIGHLIGHT_CLASS);
  }

  // Find the video element associated with a videoId
  // Strategy:
  // 1. Look for element with matching ID (some sites use videoId as element ID)
  // 2. Look for video element whose src/data-src contains the videoId
  // 3. Look for a container with the videoId, find video inside it
  // 4. Fallback: the main Plyr/player video (class="player")
  // 5. Final fallback: largest visible video
  function findVideoByVideoId(videoId) {
    if (!videoId) {
      // No videoId — try main player first, then largest
      const playerVideo = document.querySelector('video.player, video[data-poster], .plyr video');
      if (playerVideo) return playerVideo;
      return findLargestVideo();
    }

    // 1. Direct ID match
    const byId = document.getElementById(videoId);
    if (byId) {
      if (byId.tagName === 'VIDEO') return byId;
      const innerVideo = byId.querySelector('video');
      if (innerVideo) return innerVideo;
    }

    // 2. Video with src containing videoId
    const videos = document.querySelectorAll('video');
    for (const v of videos) {
      const src = v.src || v.getAttribute('data-src') || '';
      if (src.includes(videoId)) return v;
    }

    // 3. Any container with videoId, look for video inside
    const containers = document.querySelectorAll('[id*="' + videoId + '"], [data-id="' + videoId + '"]');
    for (const c of containers) {
      const v = c.tagName === 'VIDEO' ? c : c.querySelector('video');
      if (v) return v;
    }

    // 4. Main player video (Plyr uses class="player")
    const playerVideo = document.querySelector('video.player');
    if (playerVideo) return playerVideo;

    // 5. Fallback: largest visible video
    return findLargestVideo();
  }

  function findLargestVideo() {
    const videos = document.querySelectorAll('video');
    let largest = null;
    let maxArea = 0;
    for (const v of videos) {
      const rect = v.getBoundingClientRect();
      const area = rect.width * rect.height;
      if (area > maxArea) { maxArea = area; largest = v; }
    }
    return largest;
  }

  // --- Listen for highlight commands ---
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.type === 'highlight-video') {
      unhighlightAll();
      const video = findVideoByVideoId(message.videoId);
      if (video) {
        ensureHighlightStyle();
        video.classList.add(HIGHLIGHT_CLASS);
      }
      sendResponse({ ok: true });
    }
    if (message.type === 'unhighlight-video') {
      unhighlightAll();
      sendResponse({ ok: true });
    }
    return true;
  });
})();
