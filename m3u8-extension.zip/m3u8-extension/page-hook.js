'use strict';

// Runs in PAGE's MAIN world.
// Hooks fetch, XHR, MediaSource to detect m3u8 URLs and map them to video elements.
// Communicates with content-script.js via window.postMessage.

(function () {
  const STREAM_RE = /\.(m3u8|mpd|flv|mp4)(\?|$)/i;
  const JSON_SCAN_RE = /https?:\/\/[^\s"'\\]+\.(m3u8|mpd|flv|mp4)(?:[^\s"'\\]*)/gi;
  const MSG_TAG = '__m3u8_grabber__';

  function post(data) {
    window.postMessage({ tag: MSG_TAG, ...data }, '*');
  }

  // --- All discovered m3u8 URLs with timestamps ---
  // [{url, time}]
  const allM3u8 = [];

  function recordStream(url, source) {
    if (!url || typeof url !== 'string') return;
    if (!STREAM_RE.test(url)) return;
    allM3u8.push({ url, time: Date.now() });
    post({ type: 'stream-found', url, source });
  }

  function scanJson(text, source) {
    if (!text || text.length > 102400) return;
    const urls = [];
    let match;
    JSON_SCAN_RE.lastIndex = 0;
    while ((match = JSON_SCAN_RE.exec(text)) !== null) {
      urls.push(match[0]);
    }
    if (urls.length === 0) return;
    // Record each for mapping
    for (const u of urls) {
      allM3u8.push({ url: u, time: Date.now() });
    }
    post({ type: 'stream-found-batch', urls, source: source + '-json' });
  }

  // --- Hook fetch (once) ---
  const origFetch = window.fetch;
  window.fetch = function (...args) {
    const url = typeof args[0] === 'string' ? args[0] : (args[0]?.url || '');
    recordStream(url, 'fetch');

    return origFetch.apply(this, args).then(response => {
      try {
        const ct = response.headers?.get('content-type') || '';
        if (ct.includes('json') || ct.includes('text/plain') || ct.includes('text/html')) {
          response.clone().text().then(text => scanJson(text, 'fetch')).catch(() => {});
        }
      } catch (e) { /* */ }
      return response;
    });
  };

  // --- Hook XHR (once) ---
  const origOpen = XMLHttpRequest.prototype.open;
  const origSend = XMLHttpRequest.prototype.send;

  XMLHttpRequest.prototype.open = function (method, url, ...rest) {
    this._m3u8_url = typeof url === 'string' ? url : url?.toString() || '';
    recordStream(this._m3u8_url, 'xhr');
    return origOpen.call(this, method, url, ...rest);
  };

  XMLHttpRequest.prototype.send = function (...args) {
    this.addEventListener('load', function () {
      try {
        const ct = this.getResponseHeader('content-type') || '';
        if (ct.includes('json') || ct.includes('text/plain') || ct.includes('text/html')) {
          scanJson(this.responseText, 'xhr');
        }
      } catch (e) { /* */ }
    });
    return origSend.apply(this, args);
  };

  // --- MediaSource → video mapping ---
  // blobURL → MediaSource
  const blobToMs = new Map();
  // MediaSource → {video, bindTime}
  const msToVideo = new Map();
  // url → videoIndex (final result)
  const linkedUrls = new Set();

  // Hook URL.createObjectURL
  const origCreateObjectURL = URL.createObjectURL;
  URL.createObjectURL = function (obj) {
    const blobUrl = origCreateObjectURL.call(this, obj);
    if (obj instanceof MediaSource) {
      blobToMs.set(blobUrl, { ms: obj, createTime: Date.now() });
    }
    return blobUrl;
  };

  // Hook video.src setter
  const srcDesc = Object.getOwnPropertyDescriptor(HTMLMediaElement.prototype, 'src');
  if (srcDesc && srcDesc.set) {
    Object.defineProperty(HTMLMediaElement.prototype, 'src', {
      get: srcDesc.get,
      set: function (val) {
        srcDesc.set.call(this, val);
        if (typeof val === 'string' && val.startsWith('blob:')) {
          const entry = blobToMs.get(val);
          if (entry) {
            msToVideo.set(entry.ms, { video: this, bindTime: Date.now() });
            linkAllToVideo(this, entry.createTime);
          }
        }
      },
      configurable: true,
      enumerable: true,
    });
  }

  // Hook setAttribute for video.src
  const origSetAttr = Element.prototype.setAttribute;
  Element.prototype.setAttribute = function (name, val) {
    origSetAttr.call(this, name, val);
    if ((this.tagName === 'VIDEO' || this.tagName === 'AUDIO') &&
        name === 'src' && typeof val === 'string' && val.startsWith('blob:')) {
      const entry = blobToMs.get(val);
      if (entry) {
        msToVideo.set(entry.ms, { video: this, bindTime: Date.now() });
        linkAllToVideo(this, entry.createTime);
      }
    }
  };

  // When a video binds to MediaSource, link all m3u8 URLs fetched
  // shortly before the MediaSource was created (within 5s window)
  function linkAllToVideo(video, msCreateTime) {
    const videos = document.querySelectorAll('video');
    let videoIndex = -1;
    for (let i = 0; i < videos.length; i++) {
      if (videos[i] === video) { videoIndex = i; break; }
    }
    if (videoIndex < 0) return;

    const WINDOW = 5000; // 5 second window
    for (const entry of allM3u8) {
      if (linkedUrls.has(entry.url)) continue;
      // m3u8 fetched within 5s before MediaSource was created
      if (entry.time <= msCreateTime && entry.time >= msCreateTime - WINDOW) {
        linkedUrls.add(entry.url);
        post({ type: 'stream-video-mapped', url: entry.url, videoIndex });
      }
    }
  }

  // --- Scan DOM for media elements (video, source, a[href=".mp4"]) ---
  function scanDomForMedia(root) {
    // video/audio/source elements
    const mediaEls = root.querySelectorAll?.('video[src], audio[src], source[src]');
    if (mediaEls) {
      for (const el of mediaEls) {
        const src = el.src || el.getAttribute('src') || '';
        if (src && !src.startsWith('blob:')) recordStream(src, 'media-element');
      }
    }
    // <a href="xxx.mp4"> links (common on download/file-listing pages)
    const links = root.querySelectorAll?.('a[href]');
    if (links) {
      for (const a of links) {
        const href = a.href || '';
        if (href && /\.mp4(\?|$)/i.test(href)) recordStream(href, 'dom-link');
      }
    }
  }

  // --- Observe DOM for dynamically added media elements ---
  const observer = new MutationObserver((mutations) => {
    for (const mutation of mutations) {
      for (const node of mutation.addedNodes) {
        if (node.nodeType !== 1) continue;
        if (node.tagName === 'VIDEO' || node.tagName === 'AUDIO' || node.tagName === 'SOURCE') {
          const src = node.src || node.getAttribute('src') || '';
          if (src && !src.startsWith('blob:')) recordStream(src, 'media-element');
        }
        if (node.tagName === 'A') {
          const href = node.href || '';
          if (href && /\.mp4(\?|$)/i.test(href)) recordStream(href, 'dom-link');
        }
        // Scan children of the added node
        if (node.querySelectorAll) scanDomForMedia(node);
      }
    }
  });

  if (document.documentElement) {
    observer.observe(document.documentElement, { childList: true, subtree: true });
    // Initial scan for already-present elements
    scanDomForMedia(document);
  } else {
    document.addEventListener('DOMContentLoaded', () => {
      observer.observe(document.documentElement, { childList: true, subtree: true });
      scanDomForMedia(document);
    });
  }
})();
