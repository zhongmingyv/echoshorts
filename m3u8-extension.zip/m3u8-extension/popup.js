'use strict';

const listEl = document.getElementById('stream-list');
const toastEl = document.getElementById('toast');
const btnHome = document.getElementById('btn-home');
const btnClear = document.getElementById('btn-clear');
const btnSettings = document.getElementById('btn-settings');

btnHome.addEventListener('click', () => {
  chrome.tabs.create({ url: 'https://player.echoshorts.win' });
});
const settingsOverlay = document.getElementById('settings-overlay');
const inputPort = document.getElementById('input-port');
const btnSettingsSave = document.getElementById('btn-settings-save');
const btnSettingsCancel = document.getElementById('btn-settings-cancel');

let currentTabId = null;
let currentTabUrl = '';
let echoPlayerPort = 18632;
const streamMetaCache = new Map();

// --- Init ---
async function init() {
  // Load saved port
  const stored = await chrome.storage.sync.get({ echoPlayerPort: 18632 });
  echoPlayerPort = stored.echoPlayerPort;
  console.log('[EchoPlayer] port loaded from storage:', echoPlayerPort);
  inputPort.value = echoPlayerPort;

  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab) return;
  currentTabId = tab.id;
  currentTabUrl = tab.url || '';
  loadStreams();
}

function loadStreams() {
  chrome.runtime.sendMessage({ type: 'get-streams', tabId: currentTabId }, (res) => {
    render(res?.streams || []);
  });
}

// --- Render stream list ---
function render(streams) {
  if (streams.length === 0) {
    listEl.innerHTML = '<div class="empty">No streams detected.<br>Play a video to start.</div>';
    return;
  }
  const ranked = rankStreams(streams);
  drawStreamList(ranked);
  enrichAndRerank(ranked).catch((err) => {
    console.warn('[EchoPlayer] metadata enrich failed:', err);
  });
}

function drawStreamList(streams) {
  listEl.innerHTML = '';
  for (const stream of streams) {
    const item = document.createElement('div');
    item.className = 'stream-item stream-item--' + (stream.recoLevel || 'secondary');

    // Header row
    const row = document.createElement('div');
    row.className = 'stream-row';

    const badge = document.createElement('span');
    badge.className = 'badge ' + (stream.format || 'unknown') + ' badge-level';
    badge.textContent = stream.format || '?';
    row.appendChild(badge);

    if (stream.quality) {
      const qBadge = document.createElement('span');
      qBadge.className = 'quality-badge badge-level';
      qBadge.textContent = stream.quality;
      row.appendChild(qBadge);
    }

    if (stream.videoId) {
      const vid = document.createElement('span');
      vid.className = 'video-id';
      vid.textContent = 'Video: ' + stream.videoId;
      row.appendChild(vid);
    }

    if (stream.variantCount > 1) {
      const vc = document.createElement('span');
      vc.className = 'variant-count';
      vc.textContent = stream.variantCount + ' variants';
      row.appendChild(vc);
    }

    item.appendChild(row);

    // URL
    const urlDiv = document.createElement('div');
    urlDiv.className = 'stream-url';
    urlDiv.textContent = stream.url;
    item.appendChild(urlDiv);

    // Metadata line (async enriched)
    const metaDiv = document.createElement('div');
    metaDiv.className = 'stream-meta';
    const cached = streamMetaCache.get(stream.url);
    renderMeta(metaDiv, cached || defaultMeta(), stream.recoLevel || 'secondary');
    item.appendChild(metaDiv);

    // Hover → highlight
    item.addEventListener('mouseenter', () => {
      chrome.runtime.sendMessage({
        type: 'highlight-video',
        tabId: currentTabId,
        videoId: stream.videoId || null,
      });
    });
    item.addEventListener('mouseleave', () => {
      chrome.runtime.sendMessage({
        type: 'unhighlight-video',
        tabId: currentTabId,
      });
    });

    // Buttons row
    const btns = document.createElement('div');
    btns.className = 'btn-row';

    // Download (via EchoPlayer)
    btns.appendChild(makeBtn('Download', 'echo-dl', (b) => {
      callEchoPlayer('/download', { url: stream.url, referer: getReferer() });
    }));

    // Translate: only for HLS/FLV etc.; hide for MP4 and DASH (EchoShorts play-and-translate path targets m3u8-style).
    const fmt = (stream.format || '').toLowerCase();
    if (fmt !== 'mp4' && fmt !== 'dash') {
      btns.appendChild(makeBtn('Translate', 'echo-translate', (b) => {
        callEchoPlayer('/play-and-translate', { url: stream.url, referer: getReferer() });
      }));
    }

    item.appendChild(btns);
    listEl.appendChild(item);
  }
}

async function enrichAndRerank(streams) {
  const tasks = streams.map(async (stream) => {
    if (!streamMetaCache.has(stream.url)) {
      try {
        streamMetaCache.set(stream.url, await probeStreamMeta(stream));
      } catch (err) {
        console.warn('[EchoPlayer] metadata probe failed:', stream.url, err);
        streamMetaCache.set(stream.url, defaultMeta());
      }
    }
  });
  await Promise.all(tasks);
  const reRanked = rankStreams(streams);
  drawStreamList(reRanked);
}

function renderMeta(el, meta, level) {
  const chips = [];
  if (meta.playlistType) chips.push(meta.playlistType);
  if (meta.durationSec > 0) chips.push(formatDuration(meta.durationSec));
  if (meta.segmentCount > 0) chips.push(meta.segmentCount + ' segs');
  if (meta.bitrateKbps > 0) chips.push(meta.bitrateKbps + ' kbps');
  if (meta.mediaKind) chips.push(meta.mediaKind.toUpperCase());
  if (chips.length === 0) {
    el.textContent = 'No extra metadata';
    return;
  }
  el.innerHTML = '';
  for (const chip of chips) {
    const span = document.createElement('span');
    span.className = 'meta-chip meta-chip--' + level;
    span.textContent = chip;
    el.appendChild(span);
  }
}

function defaultMeta() {
  return {
    playlistType: '',
    durationSec: 0,
    segmentCount: 0,
    bitrateKbps: 0,
    mediaKind: '',
  };
}

async function probeStreamMeta(stream) {
  const format = (stream.format || '').toLowerCase();
  if (format === 'hls') return probeHlsMeta(stream.url);
  if (format === 'dash') return probeDashMeta(stream.url);
  if (format === 'mp4') return probeMp4Meta(stream.url);
  return defaultMeta();
}

async function probeHlsMeta(url) {
  const meta = defaultMeta();
  const text = await fetchText(url);
  const lower = text.toLowerCase();
  const isMaster = lower.includes('#ext-x-stream-inf');
  meta.playlistType = isMaster ? 'Master' : 'Variant';

  if (isMaster) {
    const streamInfs = parseMasterStreamInf(text);
    if (streamInfs.length > 0) {
      // Show best available bitrate as a quick quality indicator.
      meta.bitrateKbps = Math.round(Math.max(...streamInfs.map(s => s.bandwidth || 0)) / 1000);
      const kinds = inferMediaKindsFromCodecs(streamInfs.map(s => s.codecs).filter(Boolean));
      meta.mediaKind = kinds;
    }
    // Probe first variant for duration/segment count.
    const firstVariant = streamInfs.find(s => s.uri);
    if (firstVariant?.uri) {
      const variantUrl = new URL(firstVariant.uri, url).toString();
      const vText = await fetchText(variantUrl);
      const v = parseMediaPlaylistStats(vText);
      meta.durationSec = v.durationSec;
      meta.segmentCount = v.segmentCount;
      if (!meta.mediaKind) meta.mediaKind = inferMediaKindFromMediaPlaylist(vText);
      if (!meta.bitrateKbps && v.avgBitrateKbps) meta.bitrateKbps = v.avgBitrateKbps;
    }
    return meta;
  }

  const media = parseMediaPlaylistStats(text);
  meta.durationSec = media.durationSec;
  meta.segmentCount = media.segmentCount;
  meta.mediaKind = inferMediaKindFromMediaPlaylist(text);
  if (media.avgBitrateKbps) meta.bitrateKbps = media.avgBitrateKbps;
  return meta;
}

async function probeDashMeta(url) {
  const meta = defaultMeta();
  meta.playlistType = 'MPD';
  const text = await fetchText(url);

  const doc = new DOMParser().parseFromString(text, 'application/xml');
  const mpd = doc.querySelector('MPD');
  if (mpd) {
    const dur = parseISODurationToSec(mpd.getAttribute('mediaPresentationDuration') || '');
    if (dur > 0) meta.durationSec = dur;
  }

  const adaptationSets = Array.from(doc.querySelectorAll('AdaptationSet'));
  const reps = Array.from(doc.querySelectorAll('Representation'));
  let maxBw = 0;
  let hasAudio = false;
  let hasVideo = false;
  for (const adSet of adaptationSets) {
    const ct = (adSet.getAttribute('contentType') || '').toLowerCase();
    const mime = (adSet.getAttribute('mimeType') || '').toLowerCase();
    if (ct === 'audio' || mime.startsWith('audio/')) hasAudio = true;
    if (ct === 'video' || mime.startsWith('video/')) hasVideo = true;
  }
  for (const r of reps) {
    const bw = Number(r.getAttribute('bandwidth') || 0);
    if (bw > maxBw) maxBw = bw;
  }
  meta.bitrateKbps = Math.round(maxBw / 1000);
  meta.mediaKind = mediaKindLabel(hasAudio, hasVideo);
  meta.segmentCount = estimateDashSegments(doc);
  return meta;
}

async function probeMp4Meta(url) {
  const meta = defaultMeta();
  meta.playlistType = 'File';
  const res = await fetch(url, { method: 'HEAD' });
  const ct = (res.headers.get('content-type') || '').toLowerCase();
  const cl = Number(res.headers.get('content-length') || 0);
  const hasVideo = ct.startsWith('video/');
  const hasAudio = ct.startsWith('audio/') || hasVideo;
  meta.mediaKind = mediaKindLabel(hasAudio, hasVideo);
  if (cl > 0) {
    // Size-only fallback: rough bitrate is not reliable without duration.
    meta.bitrateKbps = 0;
  }
  return meta;
}

async function fetchText(url) {
  const res = await fetch(url);
  if (!res.ok) throw new Error('HTTP ' + res.status + ' for ' + url);
  return res.text();
}

function parseMasterStreamInf(text) {
  const lines = text.split(/\r?\n/);
  const out = [];
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i].trim();
    if (!line.startsWith('#EXT-X-STREAM-INF:')) continue;
    const attrs = line.slice('#EXT-X-STREAM-INF:'.length);
    let uri = '';
    for (let j = i + 1; j < lines.length; j++) {
      const cand = lines[j].trim();
      if (!cand) continue;
      if (!cand.startsWith('#')) {
        uri = cand;
        break;
      }
    }
    out.push({
      bandwidth: Number(getAttr(attrs, 'BANDWIDTH') || 0),
      codecs: stripQuotes(getAttr(attrs, 'CODECS') || ''),
      uri,
    });
  }
  return out;
}

function parseMediaPlaylistStats(text) {
  const lines = text.split(/\r?\n/);
  let durationSec = 0;
  let segmentCount = 0;
  let avgBitrateKbps = 0;
  const brVals = [];
  for (const line of lines) {
    const trimmed = line.trim();
    if (trimmed.startsWith('#EXTINF:')) {
      segmentCount += 1;
      const v = parseFloat(trimmed.slice('#EXTINF:'.length).split(',')[0]);
      if (!Number.isNaN(v)) durationSec += v;
    } else if (trimmed.startsWith('#EXT-X-BITRATE:')) {
      const b = Number(trimmed.slice('#EXT-X-BITRATE:'.length));
      if (b > 0) brVals.push(b);
    } else if (trimmed.startsWith('#EXT-X-STREAM-INF:')) {
      const bw = Number(getAttr(trimmed, 'BANDWIDTH') || 0);
      if (bw > 0) brVals.push(Math.round(bw / 1000));
    }
  }
  if (brVals.length > 0) {
    avgBitrateKbps = Math.round(brVals.reduce((a, b) => a + b, 0) / brVals.length);
  }
  return { durationSec: Math.round(durationSec), segmentCount, avgBitrateKbps };
}

function inferMediaKindsFromCodecs(codecsList) {
  if (!codecsList || codecsList.length === 0) return '';
  let hasAudio = false;
  let hasVideo = false;
  for (const codecs of codecsList) {
    const c = codecs.toLowerCase();
    if (/(avc|hev1|hvc1|vp9|av01)/.test(c)) hasVideo = true;
    if (/(mp4a|ac-3|ec-3|opus|aac)/.test(c)) hasAudio = true;
  }
  return mediaKindLabel(hasAudio, hasVideo);
}

function inferMediaKindFromMediaPlaylist(text) {
  const lower = text.toLowerCase();
  if (lower.includes('#ext-x-map')) return 'audio+video';
  return '';
}

function mediaKindLabel(hasAudio, hasVideo) {
  if (hasAudio && hasVideo) return 'audio+video';
  if (hasAudio) return 'audio-only';
  if (hasVideo) return 'video-only';
  return 'unknown';
}

function getAttr(attrLine, key) {
  const re = new RegExp(key + '=([^,]+)');
  const m = attrLine.match(re);
  return m ? m[1] : '';
}

function stripQuotes(v) {
  return v.replace(/^"(.*)"$/, '$1');
}

function formatDuration(sec) {
  const h = Math.floor(sec / 3600);
  const m = Math.floor((sec % 3600) / 60);
  const s = sec % 60;
  if (h > 0) return h + ':' + String(m).padStart(2, '0') + ':' + String(s).padStart(2, '0');
  return m + ':' + String(s).padStart(2, '0');
}

function parseISODurationToSec(text) {
  if (!text || !text.startsWith('P')) return 0;
  const m = text.match(/P(?:\d+Y)?(?:\d+M)?(?:\d+D)?(?:T(?:(\d+)H)?(?:(\d+)M)?(?:(\d+(?:\.\d+)?)S)?)?/);
  if (!m) return 0;
  const h = Number(m[1] || 0);
  const min = Number(m[2] || 0);
  const s = Number(m[3] || 0);
  return Math.round(h * 3600 + min * 60 + s);
}

function estimateDashSegments(doc) {
  let total = 0;
  const timelines = Array.from(doc.querySelectorAll('SegmentTimeline'));
  for (const tl of timelines) {
    const entries = Array.from(tl.querySelectorAll('S'));
    for (const e of entries) {
      const r = Number(e.getAttribute('r') || 0);
      total += 1 + Math.max(0, r);
    }
  }
  return total;
}

function rankStreams(streams) {
  const durationStats = computeDurationStats(streams);
  const scored = streams.map((stream) => {
    const meta = streamMetaCache.get(stream.url) || defaultMeta();
    const score = scoreStream(stream, meta, durationStats);
    const risk = isRiskStream(stream, meta);
    return { stream, meta, score, risk };
  });

  const safe = scored.filter((s) => !s.risk).sort((a, b) => b.score - a.score);
  const risky = scored.filter((s) => s.risk).sort((a, b) => b.score - a.score);

  const out = [];
  if (safe.length > 0) {
    out.push({ ...safe[0].stream, recoLevel: 'primary' });
    for (let i = 1; i < safe.length; i++) out.push({ ...safe[i].stream, recoLevel: 'secondary' });
  }
  for (const r of risky) out.push({ ...r.stream, recoLevel: 'risk' });
  if (safe.length === 0) {
    // All risky: keep best risky first but still marked as risk.
    return risky.map((r) => ({ ...r.stream, recoLevel: 'risk' }));
  }
  return out;
}

function scoreStream(stream, meta, durationStats) {
  let score = 0;
  const fmt = (stream.format || '').toLowerCase();
  const quality = parseQualityNumber(stream.quality);

  if (meta.playlistType === 'Master' || meta.playlistType === 'MPD') score += 40;
  if (meta.playlistType === 'Variant') score += 25;
  if (meta.playlistType === 'File') score += 20;

  // Duration-first scoring: relative to page max duration.
  if (meta.durationSec > 0 && durationStats.maxDurationSec > 0) {
    const ratio = meta.durationSec / durationStats.maxDurationSec;
    if (ratio >= 0.95) score += 120;
    else if (ratio >= 0.8) score += 80;
    else if (ratio >= 0.6) score += 45;
    else if (ratio >= 0.4) score += 20;
    else score -= 30;
  } else {
    // If duration unavailable, rely more on quality/bitrate.
    if (quality >= 1080) score += 34;
    else if (quality >= 720) score += 28;
    else if (quality >= 480) score += 18;
    else if (quality > 0) score += 10;
  }

  // Close-duration tie breaker (same video group tends to cluster here).
  if (meta.durationSec > 0 && durationStats.medianDurationSec > 0) {
    const diff = Math.abs(meta.durationSec - durationStats.medianDurationSec);
    if (diff <= Math.max(10, durationStats.medianDurationSec * 0.05)) score += 14;
  }

  if (meta.bitrateKbps >= 5000) score += 26;
  else if (meta.bitrateKbps >= 3000) score += 20;
  else if (meta.bitrateKbps >= 1500) score += 12;
  else if (meta.bitrateKbps > 0) score += 5;

  if (meta.mediaKind === 'audio+video') score += 35;
  else if (meta.mediaKind === 'video-only') score -= 18;
  else if (meta.mediaKind === 'audio-only') score -= 22;

  if (meta.segmentCount >= 30) score += 8;
  else if (meta.segmentCount > 0 && meta.segmentCount < 5) score -= 10;

  // Secondary quality weight when duration exists but candidates are close.
  if (quality >= 1080) score += 12;
  else if (quality >= 720) score += 9;
  else if (quality >= 480) score += 6;
  else if (quality > 0) score += 3;

  if (fmt === 'hls') score += 6;
  if (fmt === 'dash') score += 7;

  return score;
}

function isRiskStream(stream, meta) {
  const url = (stream.url || '').toLowerCase();
  if (/(^|[\/._-])(ad|ads|preroll|midroll|commercial|trailer|preview)([\/._-]|$)/i.test(url)) return true;
  if (meta.mediaKind === 'audio-only' || meta.mediaKind === 'video-only' || meta.mediaKind === 'unknown') return true;
  if (meta.durationSec > 0 && meta.durationSec < 45) return true;
  if (meta.bitrateKbps > 0 && meta.bitrateKbps < 350) return true;
  return false;
}

function computeDurationStats(streams) {
  const durations = [];
  for (const stream of streams) {
    const meta = streamMetaCache.get(stream.url);
    if (meta && meta.durationSec > 0) durations.push(meta.durationSec);
  }
  if (durations.length === 0) {
    return { maxDurationSec: 0, medianDurationSec: 0 };
  }
  durations.sort((a, b) => a - b);
  const maxDurationSec = durations[durations.length - 1];
  const mid = Math.floor(durations.length / 2);
  const medianDurationSec = durations.length % 2 === 0
    ? Math.round((durations[mid - 1] + durations[mid]) / 2)
    : durations[mid];
  return { maxDurationSec, medianDurationSec };
}

function parseQualityNumber(quality) {
  if (!quality) return 0;
  const m = String(quality).match(/(\d{3,4})/);
  return m ? Number(m[1]) : 0;
}

// --- Helpers ---
function makeBtn(text, cls, handler) {
  const btn = document.createElement('button');
  btn.className = 'copy-btn' + (cls ? ' ' + cls : '');
  btn.textContent = text;
  btn.addEventListener('click', (e) => {
    e.stopPropagation();
    handler(btn);
  });
  return btn;
}

function getReferer() {
  try {
    return currentTabUrl ? new URL(currentTabUrl).origin + '/' : '';
  } catch (e) {
    return '';
  }
}

async function callEchoPlayer(path, body) {
  const url = 'http://localhost:' + echoPlayerPort + path;
  console.log('[EchoPlayer] POST', url, body);
  try {
    const res = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    });
    if (!res.ok) {
      const text = await res.text().catch(() => '');
      console.error('[EchoPlayer] HTTP', res.status, text);
      showToast('EchoPlayer error: HTTP ' + res.status, true);
      return;
    }
    console.log('[EchoPlayer] OK', res.status);
  } catch (e) {
    console.error('[EchoPlayer] fetch failed:', e);
    showToast('EchoShortsPlayer is not running. Please start the application.', true);
  }
}

function showToast(msg, isError) {
  toastEl.textContent = msg;
  toastEl.className = 'copied-toast show' + (isError ? ' error' : '');
  setTimeout(() => { toastEl.className = 'copied-toast'; }, isError ? 3000 : 2000);
}

// --- Settings ---
btnSettings.addEventListener('click', () => {
  inputPort.value = echoPlayerPort;
  settingsOverlay.classList.add('show');
});

btnSettingsCancel.addEventListener('click', () => {
  settingsOverlay.classList.remove('show');
});

btnSettingsSave.addEventListener('click', async () => {
  const port = parseInt(inputPort.value, 10);
  if (port < 1024 || port > 65535) {
    showToast('Port must be between 1024 and 65535', true);
    return;
  }
  echoPlayerPort = port;
  await chrome.storage.sync.set({ echoPlayerPort: port });
  settingsOverlay.classList.remove('show');
  showToast('Port saved: ' + port);
});

// Click overlay background to close
settingsOverlay.addEventListener('click', (e) => {
  if (e.target === settingsOverlay) settingsOverlay.classList.remove('show');
});

// --- Clear ---
btnClear.addEventListener('click', () => {
  chrome.runtime.sendMessage({ type: 'clear-streams', tabId: currentTabId }, () => {
    render([]);
  });
});

init();
