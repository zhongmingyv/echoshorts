'use strict';

const listEl = document.getElementById('stream-list');
const toastEl = document.getElementById('toast');
const btnClear = document.getElementById('btn-clear');
const btnSettings = document.getElementById('btn-settings');
const settingsOverlay = document.getElementById('settings-overlay');
const inputPort = document.getElementById('input-port');
const btnSettingsSave = document.getElementById('btn-settings-save');
const btnSettingsCancel = document.getElementById('btn-settings-cancel');

let currentTabId = null;
let currentTabUrl = '';
let echoPlayerPort = 18632;

// --- Init ---
async function init() {
  // Load saved port
  const stored = await chrome.storage.sync.get({ echoPlayerPort: 18632 });
  echoPlayerPort = stored.echoPlayerPort;
  console.log('[EchoPlayer] port loaded from storage:', echoPlayerPort);
  inputPort.value = echoPlayerPort;

  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab) return;
  currentTabId = tab.id;
  currentTabUrl = tab.url || '';
  loadStreams();
}

function loadStreams() {
  chrome.runtime.sendMessage({ type: 'get-streams', tabId: currentTabId }, (res) => {
    render(res?.streams || []);
  });
}

// --- Render stream list ---
function render(streams) {
  if (streams.length === 0) {
    listEl.innerHTML = '<div class="empty">No streams detected.<br>Play a video to start.</div>';
    return;
  }

  listEl.innerHTML = '';
  for (const stream of streams) {
    const item = document.createElement('div');
    item.className = 'stream-item';

    // Header row
    const row = document.createElement('div');
    row.className = 'stream-row';

    const badge = document.createElement('span');
    badge.className = 'badge ' + (stream.format || 'unknown');
    badge.textContent = stream.format || '?';
    row.appendChild(badge);

    if (stream.quality) {
      const qBadge = document.createElement('span');
      qBadge.className = 'quality-badge';
      qBadge.textContent = stream.quality;
      row.appendChild(qBadge);
    }

    if (stream.videoId) {
      const vid = document.createElement('span');
      vid.className = 'video-id';
      vid.textContent = 'Video: ' + stream.videoId;
      row.appendChild(vid);
    }

    if (stream.variantCount > 1) {
      const vc = document.createElement('span');
      vc.className = 'variant-count';
      vc.textContent = stream.variantCount + ' variants';
      row.appendChild(vc);
    }

    item.appendChild(row);

    // URL
    const urlDiv = document.createElement('div');
    urlDiv.className = 'stream-url';
    urlDiv.textContent = stream.url;
    item.appendChild(urlDiv);

    // Hover → highlight
    item.addEventListener('mouseenter', () => {
      chrome.runtime.sendMessage({
        type: 'highlight-video',
        tabId: currentTabId,
        videoId: stream.videoId || null,
      });
    });
    item.addEventListener('mouseleave', () => {
      chrome.runtime.sendMessage({
        type: 'unhighlight-video',
        tabId: currentTabId,
      });
    });

    // Buttons row
    const btns = document.createElement('div');
    btns.className = 'btn-row';

    // Download (via EchoPlayer)
    btns.appendChild(makeBtn('Download', 'echo-dl', (b) => {
      callEchoPlayer('/download', { url: stream.url, referer: getReferer() });
    }));

    // Translate (via EchoPlayer)
    btns.appendChild(makeBtn('Translate', 'echo-translate', (b) => {
      callEchoPlayer('/play-and-translate', { url: stream.url, referer: getReferer() });
    }));

    item.appendChild(btns);
    listEl.appendChild(item);
  }
}

// --- Helpers ---
function makeBtn(text, cls, handler) {
  const btn = document.createElement('button');
  btn.className = 'copy-btn' + (cls ? ' ' + cls : '');
  btn.textContent = text;
  btn.addEventListener('click', (e) => {
    e.stopPropagation();
    handler(btn);
  });
  return btn;
}

function getReferer() {
  try {
    return currentTabUrl ? new URL(currentTabUrl).origin + '/' : '';
  } catch (e) {
    return '';
  }
}

async function callEchoPlayer(path, body) {
  const url = 'http://localhost:' + echoPlayerPort + path;
  console.log('[EchoPlayer] POST', url, body);
  try {
    const res = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    });
    if (!res.ok) {
      const text = await res.text().catch(() => '');
      console.error('[EchoPlayer] HTTP', res.status, text);
      showToast('EchoPlayer error: HTTP ' + res.status, true);
      return;
    }
    console.log('[EchoPlayer] OK', res.status);
  } catch (e) {
    console.error('[EchoPlayer] fetch failed:', e);
    showToast('EchoShortsPlayer 未启动，请先打开应用', true);
  }
}

function showToast(msg, isError) {
  toastEl.textContent = msg;
  toastEl.className = 'copied-toast show' + (isError ? ' error' : '');
  setTimeout(() => { toastEl.className = 'copied-toast'; }, isError ? 3000 : 2000);
}

// --- Settings ---
btnSettings.addEventListener('click', () => {
  inputPort.value = echoPlayerPort;
  settingsOverlay.classList.add('show');
});

btnSettingsCancel.addEventListener('click', () => {
  settingsOverlay.classList.remove('show');
});

btnSettingsSave.addEventListener('click', async () => {
  const port = parseInt(inputPort.value, 10);
  if (port < 1024 || port > 65535) {
    showToast('Port must be between 1024 and 65535', true);
    return;
  }
  echoPlayerPort = port;
  await chrome.storage.sync.set({ echoPlayerPort: port });
  settingsOverlay.classList.remove('show');
  showToast('Port saved: ' + port);
});

// Click overlay background to close
settingsOverlay.addEventListener('click', (e) => {
  if (e.target === settingsOverlay) settingsOverlay.classList.remove('show');
});

// --- Clear ---
btnClear.addEventListener('click', () => {
  chrome.runtime.sendMessage({ type: 'clear-streams', tabId: currentTabId }, () => {
    render([]);
  });
});

init();
