# Stream Recommendation Algorithm

This document describes how popup stream cards are ranked and color-coded.

## Output Rules

- `Primary` recommendation:
  - Exactly one item when at least one non-risk stream exists.
  - Always placed at the top.
  - All tags/chips use blue style.
- `Secondary` recommendation:
  - All remaining non-risk streams.
  - All tags/chips use light blue style.
- `Risk`:
  - Streams that match risk conditions.
  - All tags/chips use gray style.

No text label such as "BEST/GOOD" is shown. Recommendation is represented only by color.

## Metadata Used

For each stream, popup probes and caches metadata:

- Playlist type: `Master` / `Variant` / `MPD` / `File`
- Duration in seconds
- Segment count
- Bitrate (kbps, estimated from playlist/manifest fields)
- Media kind: `audio+video` / `audio-only` / `video-only` / `unknown`

Language metadata is intentionally not displayed.

## Ranking Flow

1. Build scored candidates (`scoreStream`).
2. Split into:
   - Non-risk streams
   - Risk streams
3. Sort each group by score descending.
4. Compose final list:
   - First non-risk item -> `Primary`
   - Remaining non-risk -> `Secondary`
   - Risk items appended at the end -> `Risk`
5. If all are risk, keep score order and mark all as `Risk`.

## Score Function (Duration First)

Total score is additive, with duration as the dominant factor.

- Playlist type:
  - `Master` / `MPD`: +40
  - `Variant`: +25
  - `File`: +20
- Relative duration score (against page max duration):
  - `duration/max >= 0.95`: +120
  - `>= 0.80`: +80
  - `>= 0.60`: +45
  - `>= 0.40`: +20
  - `< 0.40`: -30
- Close-to-median tie breaker:
  - if duration is very close to median duration (`<= max(10s, median*5%)`): +14
- Resolution (secondary weight):
  - `1080`: +12
  - `720`: +9
  - `480`: +6
  - `360+`: +3
- Bitrate:
  - `>= 5000 kbps`: +26
  - `>= 3000 kbps`: +20
  - `>= 1500 kbps`: +12
  - `> 0 kbps`: +5
- Media kind:
  - `audio+video`: +35
  - `video-only`: -18
  - `audio-only`: -22
- Segment count:
  - `>= 30`: +8
  - `< 5` and known: -10
- Format bonus:
  - `hls`: +6
  - `dash`: +7

If duration is unavailable for a stream, the algorithm temporarily relies more on resolution/bitrate.

## Risk Conditions

A stream is marked `Risk` when one or more conditions match:

- URL contains ad-like tokens:
  - `ad`, `ads`, `preroll`, `midroll`, `commercial`, `trailer`, `preview`
- Media kind is:
  - `audio-only`, `video-only`, or `unknown`
- Duration is known and `< 45s`
- Bitrate is known and `< 350 kbps`

## Notes

- Metadata probing is asynchronous; popup first renders quickly, then reranks after metadata arrives.
- Metadata is cached by URL during popup session to reduce repeated requests.
