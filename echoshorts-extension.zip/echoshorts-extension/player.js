'use strict';

const params = new URLSearchParams(location.search);
const m3u8Url = params.get('url');
const referer = params.get('referer') || '';

const urlDisplay = document.getElementById('url-display');
const video = document.getElementById('video');
const errorDiv = document.getElementById('error');
const infoDiv = document.getElementById('info');
const btnCopy = document.getElementById('btn-copy');

urlDisplay.textContent = m3u8Url || 'No URL provided';
document.title = 'M3U8 Player - ' + (m3u8Url || '');

btnCopy.addEventListener('click', () => {
  navigator.clipboard.writeText(m3u8Url).then(() => {
    btnCopy.textContent = 'Copied!';
    setTimeout(() => btnCopy.textContent = 'Copy URL', 1200);
  });
});

if (!m3u8Url) {
  errorDiv.textContent = 'No m3u8 URL provided.';
  errorDiv.style.display = 'block';
} else if (Hls.isSupported()) {
  const hls = new Hls({
    debug: false,
    enableWorker: true,
  });

  hls.loadSource(m3u8Url);
  hls.attachMedia(video);

  hls.on(Hls.Events.MANIFEST_PARSED, function (event, data) {
    const levels = data.levels || [];
    const info = levels.map(l =>
      (l.width || '?') + 'x' + (l.height || '?') + ' @ ' + Math.round((l.bitrate || 0) / 1000) + 'kbps'
    ).join(' | ');
    infoDiv.textContent = 'Qualities: ' + (info || 'unknown');
    video.play().catch(() => {});
  });

  hls.on(Hls.Events.ERROR, function (event, data) {
    if (data.fatal) {
      errorDiv.textContent = 'Playback error: ' + data.type + ' - ' + data.details;
      errorDiv.style.display = 'block';
      if (data.type === Hls.ErrorTypes.NETWORK_ERROR) {
        errorDiv.textContent += ' (The stream may require authentication or has expired)';
      }
    }
  });
} else if (video.canPlayType('application/vnd.apple.mpegurl')) {
  video.src = m3u8Url;
  video.play().catch(() => {});
} else {
  errorDiv.textContent = 'HLS is not supported in this browser.';
  errorDiv.style.display = 'block';
}
