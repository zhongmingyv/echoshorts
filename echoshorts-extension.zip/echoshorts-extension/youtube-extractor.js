'use strict';

// YouTube stream extractor — runs in MAIN world on youtube.com only.
// Reads ytInitialPlayerResponse, deciphers signatures, transforms n-params,
// and sends working video URLs to the extension pipeline.

(function () {
  const MSG_TAG = '__m3u8_grabber__';
  function post(data) {
    window.postMessage({ tag: MSG_TAG, ...data }, '*');
  }

  // Avoid double-injection
  if (window.__echoShorts_yt_extractor__) return;
  window.__echoShorts_yt_extractor__ = true;

  // ---- Signature decipher & n-param transform ----

  let cachedPlayerId = null;
  let cachedDecipherFunc = null;
  let cachedNTransformFunc = null;

  // Find the player base.js URL from the page
  function findPlayerBaseUrl() {
    // Method 1: from script tags
    const scripts = document.querySelectorAll('script[src*="/player/"]');
    for (const s of scripts) {
      if (/\/base\.js/.test(s.src)) return s.src;
    }
    // Method 2: from ytcfg
    try {
      const cfg = window.ytcfg?.data_;
      const jsUrl = cfg?.PLAYER_JS_URL || cfg?.WEB_PLAYER_CONTEXT_CONFIGS?.WEB_PLAYER_CONTEXT_CONFIG_ID_KEVLAR_WATCH?.jsUrl;
      if (jsUrl) return jsUrl.startsWith('http') ? jsUrl : 'https://www.youtube.com' + jsUrl;
    } catch (e) { /* */ }
    // Method 3: regex scan the page HTML
    const match = document.documentElement.innerHTML.match(/\/s\/player\/([a-zA-Z0-9_-]+)\/player_ias\.vflset\/[^"]+?\/base\.js/);
    if (match) return 'https://www.youtube.com' + match[0];
    return null;
  }

  function extractPlayerId(baseUrl) {
    const m = baseUrl.match(/\/player\/([a-zA-Z0-9_-]+)\//);
    return m ? m[1] : null;
  }

  // Extract the signature decipher function from base.js source
  // Based on well-known patterns used by yt-dlp and youtubei.js
  function extractDecipherFunction(playerSource) {
    // Step 1: Find the top-level decipher function name
    // Pattern: looks for something like: a]&&(b=a.get("n"))&&(b=Xy[0](b)||b,a.set("n",b) or
    // var Xy=[funcName]; or the sig function set
    // yt-dlp pattern: \b[cs]\s*&&\s*[adf]\.set\([^,]+\s*,\s*encodeURIComponent\(([a-zA-Z0-9$]+)\(
    const sigFuncPatterns = [
      /\b[cs]\s*&&\s*[adf]\.set\([^,]+\s*,\s*encodeURIComponent\(([a-zA-Z0-9$]+)\(/,
      /\bm=([a-zA-Z0-9$]{2,})\(decodeURIComponent\(h\.s\)\)/,
      /\bc\s*&&\s*d\.set\([^,]+\s*,\s*(?:encodeURIComponent\s*\()([a-zA-Z0-9$]+)\(/,
      /\bc\s*&&\s*[a-z]\.set\([^,]+\s*,\s*([a-zA-Z0-9$]+)\(/,
      /\bc\s*&&\s*[a-z]\.set\([^,]+\s*,\s*encodeURIComponent\(([a-zA-Z0-9$]+)\(/,
    ];

    let sigFuncName = null;
    for (const pat of sigFuncPatterns) {
      const m = playerSource.match(pat);
      if (m) { sigFuncName = m[1]; break; }
    }

    if (!sigFuncName) {
      // Fallback: look for the pattern used in signatureCipher handling
      const m2 = playerSource.match(/(?:^|[^a-zA-Z0-9$])([a-zA-Z0-9$]{2,})\s*=\s*function\(\s*a\s*\)\s*\{\s*a\s*=\s*a\.split\(\s*""\s*\)/);
      if (m2) sigFuncName = m2[1];
    }

    if (!sigFuncName) return null;

    // Step 2: Extract the function body
    const escapedName = sigFuncName.replace(/\$/g, '\\$');
    const funcMatch = playerSource.match(
      new RegExp(`(?:^|[;\\n])\\s*(?:var\\s+)?${escapedName}\\s*=\\s*function\\(([^)]+)\\)\\s*\\{([^}]+)\\}`)
    );
    if (!funcMatch) return null;

    const funcBody = funcMatch[2];

    // Step 3: Find the helper object (contains reverse, splice, swap operations)
    const helperObjMatch = funcBody.match(/([a-zA-Z0-9$]{2,})\.[a-zA-Z0-9$]{2,}\(/);
    if (!helperObjMatch) return null;
    const helperObjName = helperObjMatch[1];

    const escapedHelper = helperObjName.replace(/\$/g, '\\$');
    const helperMatch = playerSource.match(
      new RegExp(`var\\s+${escapedHelper}\\s*=\\s*\\{([\\s\\S]*?)\\};`)
    );
    if (!helperMatch) return null;

    // Step 4: Build the decipher function
    const helperCode = `var ${helperObjName} = {${helperMatch[1]}};`;
    const decipherCode = `${helperCode}\nfunction decipher(a) { a = a.split(""); ${funcBody}; return a.join(""); }`;

    try {
      const fn = new Function(`${decipherCode}\nreturn decipher;`)();
      return fn;
    } catch (e) {
      console.warn('[EchoShorts] Failed to build decipher function:', e);
      return null;
    }
  }

  // Extract the n-parameter transform function from base.js source
  function extractNTransformFunction(playerSource) {
    // yt-dlp patterns for n-parameter function
    const nFuncPatterns = [
      // Pattern: b=a.get("n"))&&(b=Xy[0](b)||b,a.set("n",b)
      /\.get\("n"\)\)&&\(b=([a-zA-Z0-9$]+)(?:\[(\d+)\])?\(b\)/,
      // Pattern: var Xy=[funcName];
      /(?:^|[;\n])([a-zA-Z0-9$]{2,})\s*=\s*function\(\s*a\s*\)\s*\{\s*var\s+b\s*=\s*a\.split\(\s*""\s*\)/m,
    ];

    let nFuncName = null;
    let nArrayIdx = null;

    for (const pat of nFuncPatterns) {
      const m = playerSource.match(pat);
      if (m) {
        nFuncName = m[1];
        nArrayIdx = m[2] || null;
        break;
      }
    }

    if (!nFuncName) return null;

    // If it's an array reference like Xy[0], find what Xy is
    if (nArrayIdx !== null) {
      const escapedArr = nFuncName.replace(/\$/g, '\\$');
      const arrMatch = playerSource.match(
        new RegExp(`var\\s+${escapedArr}\\s*=\\s*\\[([a-zA-Z0-9$]+)\\]`)
      );
      if (arrMatch) nFuncName = arrMatch[1];
    }

    // Extract the function body — it's usually a large function
    const escapedName = nFuncName.replace(/\$/g, '\\$');

    // Try: function funcName(a) { ... }
    let funcSource = null;
    const funcPatterns = [
      new RegExp(`(?:^|[;\\n])\\s*${escapedName}\\s*=\\s*function\\(([^)]+)\\)\\s*\\{([\\s\\S]*?)\\}\\s*;`, 'm'),
      new RegExp(`(?:^|[;\\n])\\s*function\\s+${escapedName}\\s*\\(([^)]+)\\)\\s*\\{([\\s\\S]*?)\\n\\}`, 'm'),
    ];

    for (const pat of funcPatterns) {
      const m = playerSource.match(pat);
      if (m) {
        funcSource = m[0];
        break;
      }
    }

    if (!funcSource) return null;

    try {
      // The n-transform function is self-contained, so we can eval it directly
      const fn = new Function(`${funcSource}\nreturn ${nFuncName};`)();
      return fn;
    } catch (e) {
      // The function might reference other closures. Try a simpler approach:
      // extract and compile just the critical transform logic
      console.warn('[EchoShorts] Failed to build n-transform function:', e);
      return null;
    }
  }

  async function loadDecipherFunctions() {
    const baseUrl = findPlayerBaseUrl();
    if (!baseUrl) {
      console.warn('[EchoShorts] Could not find YouTube player base.js URL');
      return false;
    }

    const playerId = extractPlayerId(baseUrl);
    if (playerId === cachedPlayerId && cachedDecipherFunc) {
      return true; // already cached for this player version
    }

    try {
      const resp = await fetch(baseUrl);
      const source = await resp.text();

      cachedDecipherFunc = extractDecipherFunction(source);
      cachedNTransformFunc = extractNTransformFunction(source);
      cachedPlayerId = playerId;

      if (cachedDecipherFunc) {
        console.log('[EchoShorts] Sig decipher function extracted for player', playerId);
      } else {
        console.warn('[EchoShorts] Could not extract sig decipher function');
      }

      if (cachedNTransformFunc) {
        console.log('[EchoShorts] N-transform function extracted for player', playerId);
      } else {
        console.warn('[EchoShorts] Could not extract n-transform function (downloads may be throttled)');
      }

      return !!cachedDecipherFunc;
    } catch (e) {
      console.warn('[EchoShorts] Failed to fetch/parse base.js:', e);
      return false;
    }
  }

  // Process a single format entry, returning a working URL or null
  function processFormat(fmt) {
    let url = fmt.url || null;

    // Handle signatureCipher (encrypted signature)
    if (!url && fmt.signatureCipher) {
      const params = new URLSearchParams(fmt.signatureCipher);
      const s = params.get('s');
      const sp = params.get('sp') || 'signature';
      url = params.get('url');

      if (url && s && cachedDecipherFunc) {
        try {
          const sig = cachedDecipherFunc(decodeURIComponent(s));
          const u = new URL(url);
          u.searchParams.set(sp, sig);
          url = u.toString();
        } catch (e) {
          console.warn('[EchoShorts] Sig decipher failed for itag', fmt.itag, e);
          return null;
        }
      } else if (!cachedDecipherFunc) {
        return null; // can't decipher without the function
      }
    }

    if (!url) return null;

    // Transform n-parameter to avoid throttling
    if (cachedNTransformFunc) {
      try {
        const u = new URL(url);
        const n = u.searchParams.get('n');
        if (n) {
          const transformed = cachedNTransformFunc(n);
          u.searchParams.set('n', transformed);
          url = u.toString();
        }
      } catch (e) {
        // Non-fatal: URL will work but may be throttled
        console.warn('[EchoShorts] N-transform failed, download may be throttled');
      }
    }

    return url;
  }

  // ---- Extract and send streams ----

  function extractVideoId() {
    const m = location.search.match(/[?&]v=([a-zA-Z0-9_-]{11})/);
    return m ? m[1] : null;
  }

  function extractTitle() {
    try {
      const resp = window.ytInitialPlayerResponse || window.ytInitialData;
      return resp?.videoDetails?.title || document.title.replace(/ - YouTube$/, '') || '';
    } catch (e) { return ''; }
  }

  const processedVideoIds = new Set();

  async function processPlayerResponse(playerResponse) {
    if (!playerResponse?.streamingData) return;

    // Dedup: don't process the same video twice
    const vid = playerResponse.videoDetails?.videoId || extractVideoId();
    if (vid && processedVideoIds.has(vid)) return;
    if (vid) processedVideoIds.add(vid);

    const sd = playerResponse.streamingData;
    const allFormats = [
      ...(sd.formats || []),
      ...(sd.adaptiveFormats || []),
    ];

    if (allFormats.length === 0) return;

    // Try loading decipher functions (needed for most formats)
    await loadDecipherFunctions();

    const videoId = extractVideoId();
    const title = extractTitle();
    const streams = [];

    for (const fmt of allFormats) {
      const url = processFormat(fmt);
      if (!url) continue;

      streams.push({
        url,
        itag: fmt.itag,
        mimeType: fmt.mimeType || '',
        quality: fmt.qualityLabel || fmt.quality || '',
        width: fmt.width || 0,
        height: fmt.height || 0,
        bitrate: fmt.bitrate || 0,
        contentLength: fmt.contentLength || '',
        fps: fmt.fps || 0,
        hasVideo: !!(fmt.width && fmt.height),
        hasAudio: !!(fmt.audioQuality || fmt.audioSampleRate),
      });
    }

    if (streams.length > 0) {
      console.log(`[EchoShorts] YouTube: found ${streams.length} streams for video ${videoId}`);
      post({
        type: 'youtube-streams-found',
        videoId,
        title,
        streams,
      });
    }
  }

  // ---- Capture player response ----

  // Method 1: Read ytInitialPlayerResponse (set on initial page load)
  function tryReadInitialResponse() {
    if (window.ytInitialPlayerResponse?.streamingData) {
      processPlayerResponse(window.ytInitialPlayerResponse);
      return true;
    }
    return false;
  }

  // Method 2: Intercept ytInitialPlayerResponse assignment
  function hookInitialResponse() {
    let _initialResponse = window.ytInitialPlayerResponse;

    try {
      Object.defineProperty(window, 'ytInitialPlayerResponse', {
        get() { return _initialResponse; },
        set(val) {
          _initialResponse = val;
          if (val?.streamingData) {
            // Delay to let YouTube finish processing
            setTimeout(() => processPlayerResponse(val), 100);
          }
        },
        configurable: true,
      });
    } catch (e) {
      // Fallback: poll for it
      const interval = setInterval(() => {
        if (window.ytInitialPlayerResponse?.streamingData) {
          clearInterval(interval);
          processPlayerResponse(window.ytInitialPlayerResponse);
        }
      }, 500);
      // Stop polling after 30s
      setTimeout(() => clearInterval(interval), 30000);
    }
  }

  // Method 3: Handle SPA navigation (YouTube is a single-page app)
  // Uses yt-navigate-finish event + polling the player element for new video data.
  // Does NOT re-hook fetch/XHR (page-hook.js already does that).
  let lastProcessedVideoId = null;

  function hookSpaNavigation() {
    // SPA navigation handler
    document.addEventListener('yt-navigate-finish', () => {
      const newVideoId = extractVideoId();
      if (!newVideoId || newVideoId === lastProcessedVideoId) return;

      // After SPA navigation, try multiple methods to get the new player response
      setTimeout(() => {
        try {
          // Method A: ytd-watch-flexy component internal data
          const watchFlexy = document.querySelector('ytd-watch-flexy');
          const playerResp = watchFlexy?.__data?.playerResponse
            || watchFlexy?.playerResponse;
          if (playerResp?.streamingData) {
            lastProcessedVideoId = newVideoId;
            processPlayerResponse(playerResp);
            return;
          }
        } catch (e) { /* */ }

        try {
          // Method B: movie_player API
          const player = document.querySelector('#movie_player');
          const resp = player?.getPlayerResponse?.();
          if (resp?.streamingData) {
            lastProcessedVideoId = newVideoId;
            processPlayerResponse(resp);
            return;
          }
        } catch (e) { /* */ }

        // Method C: re-read ytInitialPlayerResponse (sometimes updated on SPA nav)
        if (window.ytInitialPlayerResponse?.streamingData) {
          const vid = window.ytInitialPlayerResponse?.videoDetails?.videoId;
          if (vid === newVideoId) {
            lastProcessedVideoId = newVideoId;
            processPlayerResponse(window.ytInitialPlayerResponse);
          }
        }
      }, 1500);
    });

    // Also listen to page-hook's fetch responses via postMessage
    // page-hook.js scans JSON responses — if it finds a /youtubei/v1/player response,
    // the JSON will contain streamingData. We handle this via a message listener.
    window.addEventListener('message', (event) => {
      if (event.source !== window) return;
      const data = event.data;
      // If page-hook.js scanned a fetch/XHR response containing YouTube player data
      if (data?.tag === MSG_TAG && data.type === 'stream-found-batch') {
        // Not directly useful here, but we can check ytInitialPlayerResponse again
      }
    });
  }

  // ---- Initialize ----

  // Only run on YouTube watch pages
  if (!location.hostname.endsWith('youtube.com')) return;

  // Hook the initial response assignment (for first page load)
  hookInitialResponse();

  // Hook SPA navigation
  hookSpaNavigation();

  // Try to read immediately if already available
  if (document.readyState === 'complete' || document.readyState === 'interactive') {
    setTimeout(tryReadInitialResponse, 500);
  } else {
    document.addEventListener('DOMContentLoaded', () => {
      setTimeout(tryReadInitialResponse, 500);
    });
  }
})();
