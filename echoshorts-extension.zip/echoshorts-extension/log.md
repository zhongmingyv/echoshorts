## 2026-04-25

- 在 `popup.js` 增加流元信息探测与展示逻辑（异步探测 + URL 级缓存），用于辅助选择正确下载链接。
- 新增可展示信息：`Master/Variant/MPD/File`、时长、片段数、码率、音视频类型（audio+video/audio-only/video-only/unknown）、音轨语言。
- 为 HLS 增加播放列表解析（`#EXT-X-STREAM-INF`、`#EXTINF`、`#EXT-X-MEDIA`）并对首个 Variant 进行补充探测。
- 为 DASH 增加 MPD XML 解析（总时长、表示层码率、音视频轨、音轨语言、SegmentTimeline 片段估算）。
- 为 MP4 增加 HEAD 探测（内容类型推断音视频类型）。
- 在 `popup.html` 增加 `.stream-meta` 样式以展示元信息行。
- 按新需求将推荐改为“纯颜色表达”，不再展示 BEST/GOOD 文案：主推荐=蓝色、次推荐=浅蓝、风险=灰色。
- 在 `popup.js` 新增评分与风险判定逻辑，并在元信息探测完成后自动重排：主推荐固定排第一，风险项后置。
- 在 `popup.js` 去除语言展示，仅保留时长、playlist 类型、片段数、码率、媒体类型等用于筛选的标签。
- 在 `popup.html` 增加分级配色样式（`.stream-item--primary/secondary/risk`）并统一作用于所有标签。
- 新增算法文档 `docs/recommendation-algorithm.md`，详细记录评分维度、阈值、风险规则与排序流程。
- 按“时长优先”策略重构 `popup.js` 排序：以同页最长时长为基准做相对评分，并加入“接近中位时长”的并列打分。
- 新增 `computeDurationStats()` 与 `parseQualityNumber()`，当拿不到时长时自动回退到分辨率/码率驱动排序。
- 更新 `docs/recommendation-algorithm.md`，明确时长主导阈值（0.95/0.8/0.6/0.4）及回退策略。
- 修复角标数字与列表不同步：在 `background.js` 处理 `get-streams` 时同步调用 `updateBadge(tabId, grouped.length)`，确保列表为空时角标立即清零（包括 service worker 重启后的陈旧角标）。
- 在 `popup.js` 中，当流格式为 `mp4` 或 `dash` 时隐藏 **Translate** 按钮，仅保留 **Download**（与主程序 play-and-translate 针对 HLS 的路径一致）。
- `popup.js`：连接失败时的 Toast 文案由中文改为英文：`EchoShortsPlayer is not running. Please start the application.`
