'use strict';

// Runs in PAGE's MAIN world.
// Hooks fetch, XHR, MediaSource to detect m3u8 URLs and map them to video elements.
// Communicates with content-script.js via window.postMessage.

(function () {
  const STREAM_RE = /\.(m3u8|mpd|flv|mp4|webm|mkv|mp3|ogg|aac)(\?|$)/i;
  const JSON_SCAN_RE = /https?:\/\/[^\s"'\\]+\.(m3u8|mpd|flv|mp4|webm|mkv|mp3|ogg|aac)(?:[^\s"'\\]*)/gi;
  // MIME types that indicate media content
  const MEDIA_MIME_RE = /^(video|audio)\//i;
  const NOISE_RE = /\b(tracking|beacon|pixel|telemetry|analytics|favicon|thumbnail|thumb_|poster)\b/i;
  const NON_MEDIA_EXT_RE = /\.(js|css|json|html|htm|xml|woff2?|ttf|eot|svg|png|jpe?g|gif|webp|ico|wasm)(\?|$)/i;
  const MSG_TAG = '__m3u8_grabber__';

  function post(data) {
    window.postMessage({ tag: MSG_TAG, ...data }, '*');
  }

  // --- All discovered stream URLs with timestamps ---
  // [{url, time}]
  const allM3u8 = [];
  const seenUrls = new Set();

  function recordStream(url, source) {
    if (!url || typeof url !== 'string') return;
    if (seenUrls.has(url)) return;
    if (!STREAM_RE.test(url)) return;
    seenUrls.add(url);
    allM3u8.push({ url, time: Date.now() });
    post({ type: 'stream-found', url, source });
  }

  // Record a stream detected by MIME type (URL may not have a media extension)
  function recordStreamByMime(url, mimeType, source) {
    if (!url || typeof url !== 'string') return;
    if (seenUrls.has(url)) return;
    if (NOISE_RE.test(url) || NON_MEDIA_EXT_RE.test(url)) return;
    seenUrls.add(url);
    allM3u8.push({ url, time: Date.now() });
    post({ type: 'stream-found', url, source, mimeType });
  }

  function scanJson(text, source) {
    if (!text || text.length > 102400) return;
    const urls = [];
    let match;
    JSON_SCAN_RE.lastIndex = 0;
    while ((match = JSON_SCAN_RE.exec(text)) !== null) {
      urls.push(match[0]);
    }
    if (urls.length === 0) return;
    // Record each for mapping
    for (const u of urls) {
      if (!seenUrls.has(u)) {
        seenUrls.add(u);
        allM3u8.push({ url: u, time: Date.now() });
      }
    }
    post({ type: 'stream-found-batch', urls, source: source + '-json' });
  }

  // --- Hook fetch (once) ---
  const origFetch = window.fetch;
  window.fetch = function (...args) {
    const url = typeof args[0] === 'string' ? args[0] : (args[0]?.url || '');
    recordStream(url, 'fetch');

    return origFetch.apply(this, args).then(response => {
      try {
        const ct = response.headers?.get('content-type') || '';
        // Detect media by MIME type even if URL has no extension
        if (MEDIA_MIME_RE.test(ct)) {
          recordStreamByMime(url, ct, 'fetch-mime');
        }
        if (ct.includes('json') || ct.includes('text/plain') || ct.includes('text/html')) {
          response.clone().text().then(text => scanJson(text, 'fetch')).catch(() => {});
        }
      } catch (e) { /* */ }
      return response;
    });
  };

  // --- Hook XHR (once) ---
  const origOpen = XMLHttpRequest.prototype.open;
  const origSend = XMLHttpRequest.prototype.send;

  XMLHttpRequest.prototype.open = function (method, url, ...rest) {
    this._m3u8_url = typeof url === 'string' ? url : url?.toString() || '';
    recordStream(this._m3u8_url, 'xhr');
    return origOpen.call(this, method, url, ...rest);
  };

  XMLHttpRequest.prototype.send = function (...args) {
    this.addEventListener('load', function () {
      try {
        const ct = this.getResponseHeader('content-type') || '';
        // Detect media by MIME type even if URL has no extension
        if (MEDIA_MIME_RE.test(ct)) {
          recordStreamByMime(this._m3u8_url, ct, 'xhr-mime');
        }
        if (ct.includes('json') || ct.includes('text/plain') || ct.includes('text/html')) {
          scanJson(this.responseText, 'xhr');
        }
      } catch (e) { /* */ }
    });
    return origSend.apply(this, args);
  };

  // --- MediaSource → video mapping ---
  // blobURL → MediaSource
  const blobToMs = new Map();
  // MediaSource → {video, bindTime}
  const msToVideo = new Map();
  // url → videoIndex (final result)
  const linkedUrls = new Set();

  // Hook URL.createObjectURL
  const origCreateObjectURL = URL.createObjectURL;
  URL.createObjectURL = function (obj) {
    const blobUrl = origCreateObjectURL.call(this, obj);
    if (obj instanceof MediaSource) {
      blobToMs.set(blobUrl, { ms: obj, createTime: Date.now() });
    }
    return blobUrl;
  };

  // Hook video.src setter
  const srcDesc = Object.getOwnPropertyDescriptor(HTMLMediaElement.prototype, 'src');
  if (srcDesc && srcDesc.set) {
    Object.defineProperty(HTMLMediaElement.prototype, 'src', {
      get: srcDesc.get,
      set: function (val) {
        srcDesc.set.call(this, val);
        if (typeof val === 'string' && val.startsWith('blob:')) {
          const entry = blobToMs.get(val);
          if (entry) {
            msToVideo.set(entry.ms, { video: this, bindTime: Date.now() });
            linkAllToVideo(this, entry.createTime);
          }
        }
      },
      configurable: true,
      enumerable: true,
    });
  }

  // Hook setAttribute for video.src
  const origSetAttr = Element.prototype.setAttribute;
  Element.prototype.setAttribute = function (name, val) {
    origSetAttr.call(this, name, val);
    if ((this.tagName === 'VIDEO' || this.tagName === 'AUDIO') &&
        name === 'src' && typeof val === 'string' && val.startsWith('blob:')) {
      const entry = blobToMs.get(val);
      if (entry) {
        msToVideo.set(entry.ms, { video: this, bindTime: Date.now() });
        linkAllToVideo(this, entry.createTime);
      }
    }
  };

  // When a video binds to MediaSource, link all m3u8 URLs fetched
  // shortly before the MediaSource was created (within 5s window)
  function linkAllToVideo(video, msCreateTime) {
    const videos = document.querySelectorAll('video');
    let videoIndex = -1;
    for (let i = 0; i < videos.length; i++) {
      if (videos[i] === video) { videoIndex = i; break; }
    }
    if (videoIndex < 0) return;

    const WINDOW = 5000; // 5 second window
    for (const entry of allM3u8) {
      if (linkedUrls.has(entry.url)) continue;
      // m3u8 fetched within 5s before MediaSource was created
      if (entry.time <= msCreateTime && entry.time >= msCreateTime - WINDOW) {
        linkedUrls.add(entry.url);
        post({ type: 'stream-video-mapped', url: entry.url, videoIndex });
      }
    }
  }

  // --- Scan DOM for media elements (video, source, a[href=".mp4"]) ---
  function scanDomForMedia(root) {
    // video/audio/source elements
    const mediaEls = root.querySelectorAll?.('video[src], audio[src], source[src]');
    if (mediaEls) {
      for (const el of mediaEls) {
        const src = el.src || el.getAttribute('src') || '';
        if (src && !src.startsWith('blob:')) recordStream(src, 'media-element');
      }
    }
    // <a href="xxx.mp4"> links (common on download/file-listing pages)
    const links = root.querySelectorAll?.('a[href]');
    if (links) {
      for (const a of links) {
        const href = a.href || '';
        if (href && STREAM_RE.test(href)) recordStream(href, 'dom-link');
      }
    }
  }

  // --- Observe DOM for dynamically added media elements ---
  const observer = new MutationObserver((mutations) => {
    for (const mutation of mutations) {
      for (const node of mutation.addedNodes) {
        if (node.nodeType !== 1) continue;
        if (node.tagName === 'VIDEO' || node.tagName === 'AUDIO' || node.tagName === 'SOURCE') {
          const src = node.src || node.getAttribute('src') || '';
          if (src && !src.startsWith('blob:')) recordStream(src, 'media-element');
        }
        if (node.tagName === 'A') {
          const href = node.href || '';
          if (href && STREAM_RE.test(href)) recordStream(href, 'dom-link');
        }
        // Scan children of the added node
        if (node.querySelectorAll) scanDomForMedia(node);
      }
    }
  });

  if (document.documentElement) {
    observer.observe(document.documentElement, { childList: true, subtree: true });
    // Initial scan for already-present elements
    scanDomForMedia(document);
  } else {
    document.addEventListener('DOMContentLoaded', () => {
      observer.observe(document.documentElement, { childList: true, subtree: true });
      scanDomForMedia(document);
    });
  }

  // --- MSE Recording: hook SourceBuffer.appendBuffer ---
  // Detect active MediaSource streams and support recording their data.
  // Each MediaSource gets a unique ID. When recording is enabled for a stream,
  // appendBuffer data is forwarded to content-script for upload to backend.

  let mseStreamIdCounter = 0;
  // msId → { mediaSource, video, sourceBuffers: [{sb, mimeType, trackType}], thumbnail, duration }
  const mseStreams = new Map();
  // SourceBuffer → msId
  const sbToMsId = new Map();
  // Set of msIds currently being recorded
  const recordingStreams = new Set();
  // Pending thumbnail captures (msId → true)
  const pendingThumbnails = new Set();

  // Store init segments per SourceBuffer (first appendBuffer call contains ftyp+moov)
  // These are needed when recording starts — without them, the output file is unplayable.
  const sbInitSegments = new Map(); // SourceBuffer → { data: Uint8Array, mimeType, trackType }

  // Hook MediaSource.addSourceBuffer to track new streams
  const origAddSourceBuffer = MediaSource.prototype.addSourceBuffer;
  MediaSource.prototype.addSourceBuffer = function (mimeType) {
    const sb = origAddSourceBuffer.call(this, mimeType);
    const ms = this;

    // Find or create stream entry for this MediaSource
    let msId = null;
    for (const [id, entry] of mseStreams) {
      if (entry.mediaSource === ms) { msId = id; break; }
    }
    if (msId === null) {
      msId = 'mse_' + (++mseStreamIdCounter) + '_' + Date.now();
      mseStreams.set(msId, {
        mediaSource: ms,
        video: null,
        sourceBuffers: [],
        thumbnail: null,
        duration: 0,
        resolution: '',
      });
    }

    // Determine track type from MIME
    const trackType = /^video\//i.test(mimeType) ? 'video'
      : /^audio\//i.test(mimeType) ? 'audio' : 'unknown';

    const entry = mseStreams.get(msId);
    entry.sourceBuffers.push({ sb, mimeType, trackType });
    sbToMsId.set(sb, msId);

    // Try to find the associated <video> element
    setTimeout(() => linkMseToVideo(msId), 200);
    setTimeout(() => linkMseToVideo(msId), 1000);

    // Notify content-script about this stream
    setTimeout(() => {
      const info = mseStreams.get(msId);
      if (!info) return;
      post({
        type: 'mse-stream-found',
        msId,
        tracks: info.sourceBuffers.map(s => ({
          mimeType: s.mimeType,
          trackType: s.trackType,
        })),
        resolution: info.resolution,
        duration: info.duration,
        thumbnail: info.thumbnail,
      });
    }, 1500);

    return sb;
  };

  // Helper: convert data arg to Uint8Array
  function toUint8(data) {
    if (data instanceof ArrayBuffer) return new Uint8Array(data);
    if (data instanceof Uint8Array) return data;
    // Other TypedArray or DataView
    return new Uint8Array(data.buffer, data.byteOffset, data.byteLength);
  }

  // Helper: send data chunks via postMessage
  function sendRecordingData(msId, trackType, mimeType, bytes) {
    const CHUNK_SIZE = 384 * 1024;
    for (let offset = 0; offset < bytes.length; offset += CHUNK_SIZE) {
      const slice = bytes.slice(offset, Math.min(offset + CHUNK_SIZE, bytes.length));
      post({
        type: 'mse-recording-data',
        msId,
        trackType,
        mimeType,
        data: arrayBufferToBase64(slice),
        timestamp: Date.now(),
      });
    }
  }

  // Hook SourceBuffer.appendBuffer to intercept media data
  const origAppendBuffer = SourceBuffer.prototype.appendBuffer;
  SourceBuffer.prototype.appendBuffer = function (data) {
    origAppendBuffer.call(this, data);

    const msId = sbToMsId.get(this);
    if (!msId) return;

    const entry = mseStreams.get(msId);
    if (!entry) return;

    // Find track info for this SourceBuffer
    const trackInfo = entry.sourceBuffers.find(s => s.sb === this);
    const trackType = trackInfo?.trackType || 'unknown';

    // Capture init segment (first appendBuffer call per SourceBuffer)
    // The init segment contains ftyp+moov boxes needed to make the file playable.
    if (!sbInitSegments.has(this)) {
      const bytes = toUint8(data);
      sbInitSegments.set(this, {
        data: bytes.slice(), // copy
        mimeType: trackInfo?.mimeType || '',
        trackType,
      });
      console.log('[m3u8-grabber] Init segment captured for', trackType, '- size:', bytes.length);
    }

    // Try to capture thumbnail from video element on first video data
    if (trackType === 'video' && !entry.thumbnail && !pendingThumbnails.has(msId)) {
      pendingThumbnails.add(msId);
      setTimeout(() => captureThumbnail(msId), 500);
    }

    // Update duration/resolution from video element
    if (entry.video && !entry.resolution) {
      updateStreamInfo(msId);
    }

    // If recording, forward data chunk
    if (recordingStreams.has(msId)) {
      sendRecordingData(msId, trackType, trackInfo?.mimeType || '', toUint8(data));
    }
  };

  // Also hook the deprecated append() method (some older players use it)
  if (SourceBuffer.prototype.append) {
    const origAppend = SourceBuffer.prototype.append;
    SourceBuffer.prototype.append = function (data) {
      origAppend.call(this, data);

      const msId = sbToMsId.get(this);
      if (!msId) return;
      const entry = mseStreams.get(msId);
      if (!entry) return;
      const trackInfo = entry.sourceBuffers.find(s => s.sb === this);
      const trackType = trackInfo?.trackType || 'unknown';

      // Capture init segment
      if (!sbInitSegments.has(this)) {
        const bytes = toUint8(data);
        sbInitSegments.set(this, { data: bytes.slice(), mimeType: trackInfo?.mimeType || '', trackType });
      }

      if (trackType === 'video' && !entry.thumbnail && !pendingThumbnails.has(msId)) {
        pendingThumbnails.add(msId);
        setTimeout(() => captureThumbnail(msId), 500);
      }
      if (entry.video && !entry.resolution) updateStreamInfo(msId);
      if (recordingStreams.has(msId)) {
        sendRecordingData(msId, trackType, trackInfo?.mimeType || '', toUint8(data));
      }
    };
  }

  function arrayBufferToBase64(bytes) {
    let binary = '';
    const len = bytes.byteLength;
    for (let i = 0; i < len; i++) {
      binary += String.fromCharCode(bytes[i]);
    }
    return btoa(binary);
  }

  function linkMseToVideo(msId) {
    const entry = mseStreams.get(msId);
    if (!entry || entry.video) return;

    // Find video element whose src is a blob URL pointing to this MediaSource
    for (const [blobUrl, blobEntry] of blobToMs) {
      if (blobEntry.ms === entry.mediaSource) {
        const videos = document.querySelectorAll('video');
        for (const v of videos) {
          if (v.src === blobUrl || v.currentSrc === blobUrl) {
            entry.video = v;
            updateStreamInfo(msId);
            return;
          }
        }
      }
    }
  }

  function updateStreamInfo(msId) {
    const entry = mseStreams.get(msId);
    if (!entry || !entry.video) return;
    const v = entry.video;
    if (v.videoWidth && v.videoHeight) {
      entry.resolution = v.videoWidth + 'x' + v.videoHeight;
    }
    if (v.duration && isFinite(v.duration)) {
      entry.duration = v.duration;
    }
  }

  function captureThumbnail(msId) {
    const entry = mseStreams.get(msId);
    if (!entry) return;

    // Try to find video element if not yet linked
    if (!entry.video) linkMseToVideo(msId);
    if (!entry.video) {
      // Retry later
      setTimeout(() => captureThumbnail(msId), 2000);
      return;
    }

    const v = entry.video;
    if (v.readyState < 2 || !v.videoWidth) {
      // Not enough data yet, retry
      setTimeout(() => captureThumbnail(msId), 2000);
      return;
    }

    try {
      const canvas = document.createElement('canvas');
      const scale = Math.min(160 / v.videoWidth, 90 / v.videoHeight);
      canvas.width = Math.round(v.videoWidth * scale);
      canvas.height = Math.round(v.videoHeight * scale);
      const ctx = canvas.getContext('2d');
      ctx.drawImage(v, 0, 0, canvas.width, canvas.height);
      entry.thumbnail = canvas.toDataURL('image/jpeg', 0.7);
      updateStreamInfo(msId);

      // Send thumbnail update
      post({
        type: 'mse-stream-update',
        msId,
        thumbnail: entry.thumbnail,
        resolution: entry.resolution,
        duration: entry.duration,
      });
    } catch (e) {
      // Canvas tainted by cross-origin — can't capture
      console.warn('[m3u8-grabber] thumbnail capture failed:', e.message);
    }
  }

  // Listen for recording commands from content-script
  window.addEventListener('message', (event) => {
    if (event.source !== window) return;
    const data = event.data;
    if (!data || data.tag !== MSG_TAG) return;

    if (data.type === 'mse-start-recording') {
      const msId = data.msId;
      const entry = mseStreams.get(msId);
      if (entry) {
        recordingStreams.add(msId);

        // Send init segments first — these contain ftyp+moov headers needed for a valid file
        for (const sbEntry of entry.sourceBuffers) {
          const initSeg = sbInitSegments.get(sbEntry.sb);
          if (initSeg) {
            console.log('[m3u8-grabber] Sending init segment for', initSeg.trackType, 'size:', initSeg.data.length);
            sendRecordingData(msId, initSeg.trackType, initSeg.mimeType, initSeg.data);
          }
        }

        post({ type: 'mse-recording-started', msId });
      }
    }

    if (data.type === 'mse-stop-recording') {
      const msId = data.msId;
      recordingStreams.delete(msId);
      post({ type: 'mse-recording-stopped', msId });
    }

    if (data.type === 'mse-get-streams') {
      // Return current list of detected MSE streams
      const list = [];
      for (const [msId, entry] of mseStreams) {
        updateStreamInfo(msId);
        list.push({
          msId,
          tracks: entry.sourceBuffers.map(s => ({
            mimeType: s.mimeType,
            trackType: s.trackType,
          })),
          resolution: entry.resolution,
          duration: entry.duration,
          thumbnail: entry.thumbnail,
          recording: recordingStreams.has(msId),
        });
      }
      post({ type: 'mse-streams-list', streams: list });
    }
  });

  // --- PerformanceObserver backup ---
  // Catches media resources even when fetch/XHR hooks are bypassed
  // (e.g., player cached original fetch before our hook, or requests from Web Workers)
  try {
    const perfObserver = new PerformanceObserver((list) => {
      for (const entry of list.getEntries()) {
        const url = entry.name;
        if (!url || !url.startsWith('http')) continue;
        if (seenUrls.has(url)) continue;
        if (NOISE_RE.test(url)) continue;
        // Check if URL has a known media extension
        if (STREAM_RE.test(url)) {
          recordStream(url, 'perf-observer');
          continue;
        }
        // For cross-origin resources, transferSize/encodedBodySize are 0 (browser restriction).
        // Use duration as a proxy: large media transfers take longer than tiny assets.
        // Also accept any 'media'/'video'/'audio' initiatorType unconditionally.
        const size = entry.transferSize || entry.encodedBodySize || 0;
        const isLarge = size > 102400;                    // >100KB (same-origin)
        const isLongTransfer = size === 0 && entry.duration > 200; // cross-origin proxy
        const isMediaInit = entry.initiatorType === 'media'
          || entry.initiatorType === 'video'
          || entry.initiatorType === 'audio';

        if (isMediaInit) {
          recordStreamByMime(url, null, 'perf-' + entry.initiatorType);
        } else if ((isLarge || isLongTransfer)
            && (entry.initiatorType === 'fetch' || entry.initiatorType === 'xmlhttprequest')) {
          recordStreamByMime(url, null, 'perf-' + entry.initiatorType);
        }
      }
    });
    perfObserver.observe({ entryTypes: ['resource'] });
  } catch (e) { /* PerformanceObserver not available */ }
})();
