'use strict';

/**
 * Stream URL detection and analysis — adapted from m3u8-grabber/main/stream-analyzer.js
 * Runs in service worker context (no DOM)
 */

// MIME types that indicate streaming/media content
const STREAM_MIME_TYPES = [
  'application/vnd.apple.mpegurl',
  'application/x-mpegurl',
  'audio/mpegurl',
  'audio/x-mpegurl',
  'application/dash+xml',
  'video/x-flv',
  'video/mp2t',
  'video/mp4',
  'video/webm',
  'video/x-matroska',
  'audio/mp4',
  'audio/webm',
  'audio/mpeg',
  'audio/ogg',
  'audio/aac',
  'audio/flac',
  'video/ogg',
];

const STREAM_URL_PATTERNS = /\.(m3u8|mpd|flv|mp4)(\?|$)/i;
const TS_URL_PATTERN = /\.(ts)(\?|$)/i;

// Noise filter: skip known non-content media URLs (tiny tracking pixels, analytics, etc.)
const NOISE_URL_PATTERNS = /\b(tracking|beacon|pixel|telemetry|analytics|favicon|thumbnail|thumb_|poster)\b/i;

// Non-media file extensions that should never be treated as streams
const NON_MEDIA_EXT = /\.(js|css|json|html|htm|xml|woff2?|ttf|eot|svg|png|jpe?g|gif|webp|ico|wasm)(\?|$)/i;

function isStreamUrl(url) {
  return STREAM_URL_PATTERNS.test(url);
}

function isStreamMimeType(mimeType) {
  if (!mimeType) return false;
  const lower = mimeType.toLowerCase().split(';')[0].trim();
  return STREAM_MIME_TYPES.includes(lower);
}

function detectFormat(url) {
  if (/\.m3u8(\?|$)/i.test(url)) return 'hls';
  if (/\.mpd(\?|$)/i.test(url)) return 'dash';
  if (/\.flv(\?|$)/i.test(url)) return 'flv';
  if (/\.ts(\?|$)/i.test(url)) return 'ts';
  if (/\.mp4(\?|$)/i.test(url)) return 'mp4';
  if (/\.webm(\?|$)/i.test(url)) return 'webm';
  if (/\.mkv(\?|$)/i.test(url)) return 'mkv';
  if (/\.mp3(\?|$)/i.test(url)) return 'mp3';
  if (/\.ogg(\?|$)/i.test(url)) return 'ogg';
  if (/\.aac(\?|$)/i.test(url)) return 'aac';
  return 'unknown';
}

// Detect format from MIME type (used when URL has no recognizable extension)
function detectFormatFromMime(mimeType) {
  if (!mimeType) return 'unknown';
  const lower = mimeType.toLowerCase().split(';')[0].trim();
  if (lower.includes('mpegurl') || lower === 'application/vnd.apple.mpegurl') return 'hls';
  if (lower === 'application/dash+xml') return 'dash';
  if (lower === 'video/x-flv') return 'flv';
  if (lower === 'video/mp4' || lower === 'audio/mp4') return 'mp4';
  if (lower === 'video/webm' || lower === 'audio/webm') return 'webm';
  if (lower === 'video/x-matroska') return 'mkv';
  if (lower === 'audio/mpeg') return 'mp3';
  if (lower === 'video/ogg' || lower === 'audio/ogg') return 'ogg';
  if (lower === 'audio/aac') return 'aac';
  if (lower === 'video/mp2t') return 'ts';
  return 'unknown';
}

function isNoiseUrl(url) {
  return NOISE_URL_PATTERNS.test(url) || NON_MEDIA_EXT.test(url);
}

function isAdUrl(url) {
  return /\b(ad|preroll|midroll|commercial|trailer|preview)\b/i.test(url);
}

// Scan text for stream URLs (used for JSON responses)
function scanForStreamUrls(text) {
  if (!text || text.length > 102400) return [];
  const urls = [];
  const regex = /https?:\/\/[^\s"'\\]+\.(m3u8|mpd|flv|mp4|webm|mkv|mp3|ogg|aac)(?:[^\s"'\\]*)/gi;
  let match;
  while ((match = regex.exec(text)) !== null) {
    urls.push(match[0]);
  }
  return [...new Set(urls)];
}
