'use strict';

importScripts('stream-analyzer.js');

// Per-tab: tabId -> [{url, format, source, timestamp, frameId, isAd}]
const tabStreams = new Map();

// Per-tab MSE streams: tabId -> [{msId, tracks, resolution, duration, thumbnail, recording}]
const tabMseStreams = new Map();

// Active recording sessions: msId -> { tabId, sessionId, startTime }
const activeRecordings = new Map();

// --- webRequest interception ---
chrome.webRequest.onBeforeRequest.addListener(
  (details) => {
    if (details.tabId < 0) return;
    const url = details.url;
    if (TS_URL_PATTERN.test(url)) return;
    // 1) URL extension match (m3u8, mp4, etc.)
    if (isStreamUrl(url)) {
      addStream(details.tabId, {
        url,
        format: detectFormat(url),
        source: 'webRequest',
        timestamp: Date.now(),
        isAd: isAdUrl(url),
        frameId: details.frameId,
      });
      return;
    }
    // 2) Chrome resource type 'media' — catches <video src="..."> direct loads
    //    even when URL has no recognizable extension
    if (details.type === 'media') {
      if (isNoiseUrl(url)) return;
      addStream(details.tabId, {
        url,
        format: detectFormat(url), // may be 'unknown', resolved later by MIME
        source: 'webRequest-media',
        timestamp: Date.now(),
        isAd: isAdUrl(url),
        frameId: details.frameId,
      });
    }
  },
  { urls: ['<all_urls>'] }
);

chrome.webRequest.onHeadersReceived.addListener(
  (details) => {
    if (details.tabId < 0) return;
    const contentType = details.responseHeaders?.find(
      h => h.name.toLowerCase() === 'content-type'
    );
    if (!contentType || !isStreamMimeType(contentType.value)) return;
    const url = details.url;
    if (TS_URL_PATTERN.test(url)) return;
    // Skip noise URLs (tracking pixels, thumbnails, etc.)
    if (isNoiseUrl(url)) return;
    // Prefer URL-based format, fall back to MIME-based format
    const urlFormat = detectFormat(url);
    const mimeFormat = detectFormatFromMime(contentType.value);
    const format = urlFormat !== 'unknown' ? urlFormat : mimeFormat;
    addStream(details.tabId, {
      url,
      format,
      source: 'webRequest-mime',
      timestamp: Date.now(),
      isAd: isAdUrl(url),
      frameId: details.frameId,
    });
  },
  { urls: ['<all_urls>'] },
  ['responseHeaders']
);

// Backup: onCompleted also checks MIME — catches cases where onHeadersReceived
// missed due to MV3 service worker lifecycle or HTTP/3 edge cases.
chrome.webRequest.onCompleted.addListener(
  (details) => {
    if (details.tabId < 0) return;
    const contentType = details.responseHeaders?.find(
      h => h.name.toLowerCase() === 'content-type'
    );
    if (!contentType || !isStreamMimeType(contentType.value)) return;
    const url = details.url;
    if (TS_URL_PATTERN.test(url)) return;
    if (isNoiseUrl(url)) return;
    const urlFormat = detectFormat(url);
    const mimeFormat = detectFormatFromMime(contentType.value);
    const format = urlFormat !== 'unknown' ? urlFormat : mimeFormat;
    // addStream deduplicates, so this won't create duplicates with onHeadersReceived
    addStream(details.tabId, {
      url,
      format,
      source: 'webRequest-completed',
      timestamp: Date.now(),
      isAd: isAdUrl(url),
      frameId: details.frameId,
    });
  },
  { urls: ['<all_urls>'] },
  ['responseHeaders']
);

// --- Messages ---
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'stream-found' && sender.tab) {
    const urls = message.urls || [message.url];
    for (const url of urls) {
      if (!url) continue;
      if (TS_URL_PATTERN.test(url)) continue;
      // page-hook may pass mimeType for MIME-based detection (no URL extension)
      const urlFmt = detectFormat(url);
      const fmt = urlFmt !== 'unknown' ? urlFmt
        : (message.mimeType ? detectFormatFromMime(message.mimeType) : 'unknown');
      addStream(sender.tab.id, {
        url,
        format: fmt,
        source: message.source || 'content-script',
        timestamp: Date.now(),
        isAd: isAdUrl(url),
        frameId: sender.frameId || 0,
      });
    }
    sendResponse({ ok: true });
  }

  // YouTube extractor: batch of streams with full metadata
  if (message.type === 'youtube-streams-found' && sender.tab) {
    const { streams, videoId, title } = message;
    for (const s of (streams || [])) {
      if (!s.url) continue;
      // Determine format from mimeType (e.g. "video/mp4; codecs=...")
      const mime = (s.mimeType || '').split(';')[0].trim();
      let format = detectFormatFromMime(mime);
      if (format === 'unknown') format = detectFormat(s.url);
      addStream(sender.tab.id, {
        url: s.url,
        format,
        source: 'youtube-extractor',
        timestamp: Date.now(),
        isAd: false,
        frameId: sender.frameId || 0,
        // Extra YouTube metadata for display
        ytMeta: {
          videoId: videoId || '',
          title: title || '',
          itag: s.itag,
          quality: s.quality,
          width: s.width,
          height: s.height,
          bitrate: s.bitrate,
          fps: s.fps,
          hasVideo: s.hasVideo,
          hasAudio: s.hasAudio,
          contentLength: s.contentLength,
        },
      });
    }
    sendResponse({ ok: true });
  }

  if (message.type === 'stream-video-mapped' && sender.tab) {
    sendResponse({ ok: true });
  }

  // Get grouped streams for popup
  if (message.type === 'get-streams') {
    const streams = tabStreams.get(message.tabId) || [];
    const grouped = groupAndRank(streams);
    // Keep badge in sync with current in-memory list.
    // This also clears stale badge numbers after service worker restart.
    updateBadge(message.tabId, grouped.length);
    sendResponse({ streams: grouped });
  }

  // Highlight: forward to content scripts
  if (message.type === 'highlight-video') {
    chrome.tabs.sendMessage(message.tabId, {
      type: 'highlight-video',
      videoId: message.videoId,
    }).catch(() => {});
    sendResponse({ ok: true });
  }

  if (message.type === 'unhighlight-video') {
    chrome.tabs.sendMessage(message.tabId, { type: 'unhighlight-video' }).catch(() => {});
    sendResponse({ ok: true });
  }

  if (message.type === 'play-stream') {
    playStream(message.url, message.referer);
    sendResponse({ ok: true });
  }

  if (message.type === 'clear-streams') {
    tabStreams.delete(message.tabId);
    tabMseStreams.delete(message.tabId);
    updateBadge(message.tabId, 0);
    sendResponse({ ok: true });
  }

  // --- MSE stream messages ---

  // MSE stream detected by page-hook
  if (message.type === 'mse-stream-found' && sender.tab) {
    const tabId = sender.tab.id;
    let list = tabMseStreams.get(tabId);
    if (!list) { list = []; tabMseStreams.set(tabId, list); }
    // Dedup by msId
    if (!list.find(s => s.msId === message.msId)) {
      list.push({
        msId: message.msId,
        tracks: message.tracks || [],
        resolution: message.resolution || '',
        duration: message.duration || 0,
        thumbnail: message.thumbnail || null,
        recording: false,
      });
      console.log('[m3u8-grabber] MSE stream found:', message.msId);
    }
    sendResponse({ ok: true });
  }

  // MSE stream info updated (thumbnail, duration, resolution)
  if (message.type === 'mse-stream-update' && sender.tab) {
    const tabId = sender.tab.id;
    const list = tabMseStreams.get(tabId) || [];
    const entry = list.find(s => s.msId === message.msId);
    if (entry) {
      if (message.thumbnail) entry.thumbnail = message.thumbnail;
      if (message.resolution) entry.resolution = message.resolution;
      if (message.duration) entry.duration = message.duration;
    }
    sendResponse({ ok: true });
  }

  // Get MSE streams for popup
  if (message.type === 'get-mse-streams') {
    const list = tabMseStreams.get(message.tabId) || [];
    sendResponse({ streams: list });
  }

  // Start recording an MSE stream
  if (message.type === 'start-mse-recording') {
    const { tabId, msId } = message;
    const sessionId = 'rec_' + Date.now() + '_' + Math.random().toString(36).slice(2, 8);
    activeRecordings.set(msId, { tabId, sessionId, startTime: Date.now() });

    // Update recording state in stream list
    const list = tabMseStreams.get(tabId) || [];
    const entry = list.find(s => s.msId === msId);
    if (entry) entry.recording = true;

    // Notify backend to start a recording session
    startRecordingSession(sessionId, msId, entry?.tracks || []);

    // Forward to content-script → page-hook
    chrome.tabs.sendMessage(tabId, { type: 'mse-start-recording', msId }).catch(() => {});
    sendResponse({ ok: true, sessionId });
  }

  // Stop recording
  if (message.type === 'stop-mse-recording') {
    const { tabId, msId } = message;
    const rec = activeRecordings.get(msId);
    if (rec) {
      finishRecordingSession(rec.sessionId);
      activeRecordings.delete(msId);
    }

    // Update recording state
    const list = tabMseStreams.get(tabId) || [];
    const entry = list.find(s => s.msId === msId);
    if (entry) entry.recording = false;

    // Forward to content-script → page-hook
    chrome.tabs.sendMessage(tabId, { type: 'mse-stop-recording', msId }).catch(() => {});
    sendResponse({ ok: true });
  }

  // Recording data chunk from page-hook — upload inline to keep service worker alive
  if (message.type === 'mse-recording-data' && sender.tab) {
    const rec = activeRecordings.get(message.msId);
    if (rec) {
      console.log('[m3u8-grabber] Recording data received:', message.trackType,
        'size:', message.data?.length || 0, 'msId:', message.msId);
      // Await the upload before responding — this keeps the SW alive during the fetch
      doUploadChunk(rec.sessionId, message.trackType, message.mimeType, message.data)
        .then(() => sendResponse({ ok: true }))
        .catch(() => sendResponse({ ok: false }));
      return true; // signal async sendResponse
    } else {
      console.warn('[m3u8-grabber] Recording data for unknown msId:', message.msId);
      sendResponse({ ok: true });
    }
  }

  // Recording state confirmations from page-hook
  if (message.type === 'mse-recording-started' || message.type === 'mse-recording-stopped') {
    sendResponse({ ok: true });
  }

  return true;
});

// --- MSE Recording: communicate with EchoPlayer backend ---

// Cache port to avoid repeated async storage reads during high-frequency chunk uploads
let _cachedPort = 18632;
chrome.storage.sync.get({ echoPlayerPort: 18632 }, (r) => { _cachedPort = r.echoPlayerPort; });
chrome.storage.onChanged.addListener((changes) => {
  if (changes.echoPlayerPort) _cachedPort = changes.echoPlayerPort.newValue;
});

// Upload chunk directly — no queue, called inline from message handler
async function doUploadChunk(sessionId, trackType, mimeType, base64Data) {
  try {
    const res = await fetch(`http://localhost:${_cachedPort}/recording/chunk`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ sessionId, trackType, mimeType, data: base64Data }),
    });
    console.log('[m3u8-grabber] chunk uploaded:', trackType, 'status:', res.status);
  } catch (e) {
    console.warn('[m3u8-grabber] chunk upload failed:', e.message);
  }
}

async function startRecordingSession(sessionId, msId, tracks) {
  try {
    const res = await fetch(`http://localhost:${_cachedPort}/recording/start`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ sessionId, msId, tracks }),
    });
    console.log('[m3u8-grabber] Recording session started:', sessionId, 'status:', res.status);
  } catch (e) {
    console.error('[m3u8-grabber] Failed to start recording session:', e);
  }
}

async function finishRecordingSession(sessionId) {
  try {
    const res = await fetch(`http://localhost:${_cachedPort}/recording/finish`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ sessionId }),
    });
    console.log('[m3u8-grabber] Recording session finished:', sessionId, 'status:', res.status);
  } catch (e) {
    console.error('[m3u8-grabber] Failed to finish recording session:', e);
  }
}

// --- Group by video ID and pick best quality per group ---
// Extract video ID from URL path, e.g.:
//   /hls/197467228/master/197467228_720p.m3u8 → "197467228"
//   /video/index.m3u8 → null (use full URL as ID)
function extractVideoId(url) {
  try {
    const u = new URL(url);
    const path = u.pathname;
    // YouTube/googlevideo: group by 'id' param (video ID)
    const idParam = u.searchParams.get('id');
    if (idParam) return idParam;
    // Pattern: /hls/<id>/  or /<id>/master/ or /<id>_720p.m3u8
    const match = path.match(/\/(\d{6,})\//);
    if (match) return match[1];
    // Try filename: 197467228_720p.m3u8
    const fileMatch = path.match(/\/(\d{6,})[_\.]/);
    if (fileMatch) return fileMatch[1];
  } catch (e) { /* */ }
  return null;
}

// Quality ranking for resolution suffixes
const QUALITY_ORDER = ['720p', '1080p', '480p', '360p', '240p', '160p'];

// YouTube itag → quality mapping (common itags)
const ITAG_QUALITY = {
  // video+audio
  '18': 60,  // 360p mp4
  '22': 70,  // 720p mp4
  '37': 80,  // 1080p mp4
  // video-only (DASH)
  '134': 60, // 360p
  '135': 60, // 480p
  '136': 70, // 720p
  '137': 80, // 1080p
  '248': 80, // 1080p webm
  '247': 70, // 720p webm
  '244': 60, // 480p webm
  '243': 50, // 360p webm
  '298': 70, // 720p60
  '299': 80, // 1080p60
  '302': 70, // 720p60 webm
  '303': 80, // 1080p60 webm
  '308': 85, // 1440p webm
  '315': 90, // 2160p webm
  '271': 85, // 1440p webm
  '313': 90, // 2160p webm
  // audio-only
  '139': 20, // 48k m4a
  '140': 25, // 128k m4a
  '141': 30, // 256k m4a
  '171': 25, // 128k webm
  '172': 30, // 256k webm
  '249': 20, // 50k opus
  '250': 22, // 70k opus
  '251': 28, // 160k opus
};

function getQualityScore(url) {
  // Master playlist (no resolution suffix) = highest
  const path = url.toLowerCase();
  if (/master\.m3u8/i.test(path) && !/_\d+p/.test(path)) return 100;
  if (/auto/i.test(path)) return 90;
  if (/1080p/i.test(path)) return 80;
  if (/720p/i.test(path)) return 70;
  if (/480p/i.test(path)) return 60;
  if (/360p/i.test(path)) return 50;
  if (/240p/i.test(path)) return 40;
  if (/160p/i.test(path)) return 30;
  if (/blurred/i.test(path)) return 10;
  // YouTube itag-based quality
  try {
    const itag = new URL(url).searchParams.get('itag');
    if (itag && ITAG_QUALITY[itag]) return ITAG_QUALITY[itag];
  } catch (e) { /* */ }
  return 55; // unknown quality
}

function groupAndRank(streams) {
  const filtered = streams.filter(s => !s.isAd);
  if (filtered.length === 0) return [];

  // Group by video ID
  const groups = new Map(); // videoId → [streams]
  const ungrouped = [];

  for (const s of filtered) {
    const vid = extractVideoId(s.url);
    if (vid) {
      if (!groups.has(vid)) groups.set(vid, []);
      groups.get(vid).push(s);
    } else {
      ungrouped.push(s);
    }
  }

  const result = [];

  // For each group, pick the best quality stream
  // Prefer video+audio (muxed) streams, then highest resolution
  for (const [videoId, groupStreams] of groups) {
    groupStreams.sort((a, b) => {
      // Prefer muxed (video+audio) over single-track
      const aMuxed = a.ytMeta?.hasVideo && a.ytMeta?.hasAudio ? 1 : 0;
      const bMuxed = b.ytMeta?.hasVideo && b.ytMeta?.hasAudio ? 1 : 0;
      if (bMuxed !== aMuxed) return bMuxed - aMuxed;
      return getQualityScore(b.url) - getQualityScore(a.url);
    });
    const best = groupStreams[0];
    result.push({
      ...best,
      videoId,
      quality: best.ytMeta?.quality || getQualityLabel(best.url),
      variantCount: groupStreams.length,
    });
  }

  // Add ungrouped streams
  for (const s of ungrouped) {
    result.push({
      ...s,
      videoId: null,
      quality: s.ytMeta?.quality || getQualityLabel(s.url),
      variantCount: 1,
    });
  }

  // Sort: highest quality first
  result.sort((a, b) => getQualityScore(b.url) - getQualityScore(a.url));

  return result;
}

// YouTube itag → label mapping
const ITAG_LABEL = {
  '18': '360p', '22': '720p', '37': '1080p',
  '134': '360p', '135': '480p', '136': '720p', '137': '1080p',
  '248': '1080p', '247': '720p', '244': '480p', '243': '360p',
  '298': '720p60', '299': '1080p60', '302': '720p60', '303': '1080p60',
  '308': '1440p', '315': '2160p', '271': '1440p', '313': '2160p',
  '139': '48k', '140': '128k', '141': '256k',
  '171': '128k', '172': '256k',
  '249': '50k', '250': '70k', '251': '160k',
};

function getQualityLabel(url) {
  const path = url.toLowerCase();
  if (/1080p/i.test(path)) return '1080p';
  if (/720p/i.test(path)) return '720p';
  if (/480p/i.test(path)) return '480p';
  if (/360p/i.test(path)) return '360p';
  if (/240p/i.test(path)) return '240p';
  if (/160p/i.test(path)) return '160p';
  if (/auto/i.test(path)) return 'Auto';
  if (/master/i.test(path)) return 'Master';
  // YouTube itag
  try {
    const itag = new URL(url).searchParams.get('itag');
    if (itag && ITAG_LABEL[itag]) return ITAG_LABEL[itag];
  } catch (e) { /* */ }
  return '';
}

// --- Stream management ---

// Normalize URL to collapse range-request variants of the same stream.
// e.g., YouTube's videoplayback URLs differ only by range/rn/rbuf params.
function normalizeStreamUrl(url) {
  try {
    const u = new URL(url);
    // Remove params that vary per segment/chunk but identify the same stream
    for (const p of ['range', 'rn', 'rbuf', 'pot', 'n', 'cpn', 'clen', 'lmt', 'dur', 'alr']) {
      u.searchParams.delete(p);
    }
    return u.toString();
  } catch (e) {
    return url;
  }
}

function addStream(tabId, entry) {
  let list = tabStreams.get(tabId);
  if (!list) {
    list = [];
    tabStreams.set(tabId, list);
  }
  // Dedup by exact URL — but upgrade format/metadata if existing entry is weaker
  const existing = list.find(s => s.url === entry.url);
  if (existing) {
    // Upgrade: if existing is 'unknown' but new has a real format, update it
    if (existing.format === 'unknown' && entry.format !== 'unknown') {
      existing.format = entry.format;
      existing.source = entry.source;
      if (entry.ytMeta) existing.ytMeta = entry.ytMeta;
    }
    return;
  }
  // Also dedup by normalized URL (collapse range-request variants)
  const normUrl = normalizeStreamUrl(entry.url);
  const existingNorm = list.find(s => normalizeStreamUrl(s.url) === normUrl);
  if (existingNorm) {
    if (existingNorm.format === 'unknown' && entry.format !== 'unknown') {
      existingNorm.format = entry.format;
      existingNorm.source = entry.source;
      if (entry.ytMeta) existingNorm.ytMeta = entry.ytMeta;
    }
    return;
  }
  list.push(entry);
  console.log('[m3u8-grabber] Stream found:', entry.format, entry.source, entry.url);
  const count = groupAndRank(list).length;
  updateBadge(tabId, count);
}

function updateBadge(tabId, count) {
  const text = count > 0 ? String(count) : '';
  chrome.action.setBadgeText({ text, tabId });
  chrome.action.setBadgeBackgroundColor({ color: '#e53935', tabId });
}

// --- Play stream in new tab with Referer injection ---
const REFERER_RULE_ID_START = 1000;
let nextRuleId = REFERER_RULE_ID_START;

async function playStream(streamUrl, referer) {
  if (referer) {
    // Extract domain from stream URL to scope the rule
    let urlFilter;
    try {
      const u = new URL(streamUrl);
      urlFilter = '*://' + u.hostname + '/*';
    } catch (e) {
      urlFilter = streamUrl;
    }

    const ruleId = nextRuleId++;
    // Add dynamic rule to set Referer header for this domain
    await chrome.declarativeNetRequest.updateDynamicRules({
      removeRuleIds: [ruleId],
      addRules: [{
        id: ruleId,
        priority: 1,
        action: {
          type: 'modifyHeaders',
          requestHeaders: [
            { header: 'Referer', operation: 'set', value: referer },
            { header: 'Origin', operation: 'set', value: referer.replace(/\/$/, '') },
          ],
        },
        condition: {
          urlFilter,
          resourceTypes: ['xmlhttprequest', 'media', 'other'],
        },
      }],
    });

    // Clean up rule after 10 minutes
    setTimeout(() => {
      chrome.declarativeNetRequest.updateDynamicRules({
        removeRuleIds: [ruleId],
      }).catch(() => {});
    }, 600000);
  }

  // Open player page
  const playerUrl = chrome.runtime.getURL('player.html') +
    '?url=' + encodeURIComponent(streamUrl) +
    '&referer=' + encodeURIComponent(referer);
  chrome.tabs.create({ url: playerUrl });
}

chrome.tabs.onRemoved.addListener((tabId) => {
  tabStreams.delete(tabId);
  tabMseStreams.delete(tabId);
});

chrome.tabs.onUpdated.addListener((tabId, changeInfo) => {
  if (changeInfo.status === 'loading' && changeInfo.url) {
    tabStreams.delete(tabId);
    tabMseStreams.delete(tabId);
    updateBadge(tabId, 0);
  }
});
